# ACP v4.4 日志栈 — 单节点 PoC 快速部署(ClickHouse 后端)

本目录是 `chart/files/ck/` 的**单节点 PoC 变体**,targets 1-worker ACP 集群。设计目标是让现场演示环境能一键跑起来,**不是**生产部署路径。

## 什么时候用这个

| 条件 | ck/(标准) | ck-single/(本目录) |
|---|---|---|
| ACP worker 节点数 | ≥ 3 | 1 |
| HA 要求 | 需要(数据面全 3 副本)| 无(PoC / demo)|
| 典型场景 | 客户 POC 后转正、线上生产 | 售前演示、单机 one-box 演示 |
| 存储占用(baseline)| ~95 GiB | ~30 GiB |

**生产场景 请用 `chart/files/ck/`**。本目录任何组件单点故障都会让日志链路停摆,PVC 也都绑死在该 worker 的本地 LV 上,扩容到多节点需要数据迁移。

## 跟 3 副本版的差异

| 组件 | 3 副本版 | 单节点版 |
|---|---|---|
| Keeper | 3-pod STS + 3-server raft_configuration | **1-pod STS + 1-server raft**;`maxUnavailable=0`(不允许自愿驱逐)|
| Kafka | `KAFKA_REPLICAS=3` broker + 3 controller;topic replication 3 | `replicas=1` broker + 1 controller;topic replication 1;**`kafka.template.pod.affinity: {}` 清掉 strimzi 默认 required 反亲和** |
| ClickHouse | `CK_SHARDS × CK_REPLICAS = 1 × 3` | **强制 `1 × 1`**(install.sh 兜底覆盖),zookeeper 只配 `keeper-0` |
| aggregate-vector | `replicas=3` | `replicas=1` |
| razor | `replicas=2` | `replicas=1` |
| 节点亲和 / taint | 支持 `NODE_AFFINITY_KEY` + `TOLERATION_KEY` 固定到节点池 | 一律 `tolerations: [{operator: Exists}]`,接受所有节点 |

## 使用步骤

```bash
cd chart/files/ck-single/
cp install.env.example install.env
# 编辑 install.env:
#   STORAGE_CLASS="local-topolvmsc"   # 或你的动态 SC
# 可选:KEEPER_IMAGE(留空则从 chop CSV 自动探)

# 先 render 看一眼
./install.sh install.env --render

# 再 live
./install.sh install.env

# 验收
./check.sh install.env
```

## 限制 / 已知坑

1. **Keeper 重启 → CK 全停写**:单节点 Keeper 无 HA,pod 重启(image pull / OOMKill / node drain)期间所有 ReplicatedMergeTree DDL 会阻塞。
2. **Kafka 重启 → 日志 ingest 停**:单 broker 无副本,broker 下线 = 日志暂停进 CH。retention 默认 1h,PoC 场景通常能撑过短重启。
3. **topolvm 节点锁死**:所有 PVC 本地卷都在同一个 worker。后续扩容到多节点想分散,需要走 `kubectl scale sts/keeper --replicas=3` + 更新 `keeper_config.xml` 的 raft_configuration(手动)+ 等 PVC 在新节点 provision + sync。
4. **升级到 3 副本**:不是"改 replicas 数字"这么简单。本目录是**独立安装路径**,从 single → 3 副本应规划为"卸载 single → 用 `chart/files/ck/` 装 3 副本 + 走数据迁移",不是原地滚升级。

## 文件清单

```
chart/files/ck-single/
├── README.md                            ← 本文件
├── install.env.example                  ← PoC baseline 默认值
├── install.sh                           ← 装机主脚本(替换 build_scheduling_block 为简单 operator: Exists)
├── check.sh                             ← 验收(1-replica 断言)
└── templates/
    ├── 00-subscriptions.yaml            ← 与 ck/ 一致
    ├── 10-keeper.yaml                   ← **1-pod**,raft_configuration 只配 keeper-0
    ├── 11-chi.yaml                      ← zookeeper 只配 keeper-0,`1 × 1` 布局
    ├── 12-rdskafka.yaml                 ← `replicas: 1`,**`affinity: {}`** 覆盖 strimzi 默认
    ├── 20-kafka-user-topics.yaml        ← 与 ck/ 一致
    ├── 30-mq-conn-secret.yaml           ← 与 ck/ 一致
    ├── 31-ch-conn-secret.yaml           ← 与 ck/ 一致
    └── 40-plf.yaml                      ← 与 ck/ 一致;AGGVEC_REPLICAS / RAZOR_REPLICAS 在 install.env 默认都是 1
```

## 相关

- 3 副本版:`chart/files/ck/`(标准 PoC → 转正路径)
- OpenSearch 后端:`chart/files/os/`(3 副本,**单节点版暂不支持**:install.sh 门禁 `>= 3` + opster `required` 反亲和 + 需显式 `discovery.type: single-node`,单开 ticket)
- ES → OS 升级:`chart/files/os/upgrade-from-es.sh`
