#!/usr/bin/env bash
# =============================================================================
# SINGLE-NODE PoC / DEMO ONLY
#
# This install.sh variant targets a 1-worker ACP cluster and configures every
# component with replicas=1 and wildcard tolerations. It is intentionally
# non-HA — a worker restart stops log ingest until the worker is back.
# For production / 3-worker deployments use chart/files/ck/install.sh.
# =============================================================================

# =============================================================================
# log-storage-operator one-shot install helper
#
#   ./install.sh install.env            # apply end-to-end to the live cluster
#                                       # (if ./rendered/ already exists, each
#                                       # stage's apply reads the pre-rendered
#                                       # YAML — lets SRE --render first, hand-
#                                       # tweak, then re-run live and still get
#                                       # the script's stage ordering + waits +
#                                       # idempotence; files missing from
#                                       # ./rendered/ fall back to template render)
#   ./install.sh install.env --render   # render YAML into ./rendered/ (fixed
#                                       # dir in cwd), named by apply order.
#                                       # Zero kubectl calls — pure template
#                                       # expansion from install.env values.
#                                       # NOTE: `kubectl apply -f ./rendered`
#                                       # alone does NOT finish install:
#                                       #   * mq-conn Secret is OMITTED (needs
#                                       #     live strimzi cluster-ca-cert)
#                                       #   * 10-keeper.yaml is SKIPPED when
#                                       #     KEEPER_IMAGE is unset and chop
#                                       #     CSV isn't reachable (image can
#                                       #     only be filled from a live run)
#                                       # Correct flow: review/edit files, then
#                                       # re-run `./install.sh install.env`
#                                       # (no --render) — it picks up ./rendered/
#                                       # per stage, mints mq-conn with the live
#                                       # strimzi CA, and waits each stage ready.
#
# Reads install.env, drives a 5-stage install:
#     0  3 OLM Subscriptions (chop + strimzi + log-storage) →
#     1a Keeper quorum → 1b CHI+RdsKafka → 2 KafkaUser+Topics → 3 conn Secrets → 4 PLF
#
# IDEMPOTENT HARD-CONTRACT:
#   Running the script a second time with the SAME install.env on the SAME
#   cluster MUST be a no-op after the first successful run:
#     * all applies are server-side (field-level merge; identical content
#       produces no resourceVersion bump, no rolling update);
#     * passwords are deterministically derived from NAMESPACE/resource names
#       when install.env leaves them empty (pure sha256sum, same output);
#     * every "wait" gate short-circuits when the readiness condition already
#       holds (CSV Succeeded, CHI Completed, Kafka Pod Ready, RdsTopic
#       Ready/Active, PLF Ready=True);
#     * no stage ever mutates a resource unless its spec drifted from what the
#       template renders.
#   A mid-run failure → fix install.env / cluster condition → re-run → script
#   resumes from the failing stage; already-complete stages pass instantly.
#
# Scope: ClickHouse backend, fresh install, storage cluster only.
# Full spec: ../../docs/ONE_SHOT_INSTALL_SCRIPT.md
# =============================================================================
set -Eeuo pipefail

#--------------------------- paths & colour -----------------------------------
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL="$HERE/templates"

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; RST=$'\e[0m'
else
  BOLD=''; RED=''; GRN=''; YLW=''; RST=''
fi
log()  { printf "%s[one-shot]%s %s\n"             "$BOLD" "$RST" "$*"; }
ok()   { printf "%s[one-shot] ✓%s %s\n"           "$GRN"  "$RST" "$*"; }
warn() { printf "%s[one-shot] ! %s%s\n"           "$YLW"  "$*"   "$RST"; }
die()  { printf "%s[one-shot] ✗ %s%s\n"           "$RED"  "$*"   "$RST" >&2; exit 1; }

#--------------------------- args + env file ----------------------------------
RENDER_MODE="false"
ENV_FILE=""
for arg in "$@"; do
  case "$arg" in
    --render)   RENDER_MODE="true" ;;
    -h|--help)  sed -n '2,15p' "$0"; exit 0 ;;
    -*)         die "unknown flag: $arg (usage: $0 install.env [--render])" ;;
    *)          [[ -z "$ENV_FILE" ]] && ENV_FILE="$arg" || die "unexpected positional arg: $arg" ;;
  esac
done
[[ -n "$ENV_FILE" ]] || die "usage: $0 install.env [--render]"
[[ -r "$ENV_FILE" ]] || die "cannot read $ENV_FILE"
# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

# Render mode: write YAML to ./rendered/ (fixed dir, cwd-relative so SRE finds
# it next to the script). Zero kubectl calls — purely template expansion.
RENDER_DIR="$(pwd)/rendered"
is_render_only() { [[ "$RENDER_MODE" == "true" ]]; }
if is_render_only; then
  mkdir -p "$RENDER_DIR"
fi

#--------------------------- validate -----------------------------------------
: "${STORAGE_CLASS:?STORAGE_CLASS must be set in $ENV_FILE}"
: "${KAFKA_STORAGE_SIZE:?KAFKA_STORAGE_SIZE must be set in $ENV_FILE (e.g. 100Gi)}"
: "${CK_STORAGE_SIZE:?CK_STORAGE_SIZE must be set in $ENV_FILE (e.g. 300Gi)}"

# Enforce quantity suffix (Mi/Gi/Ti) — otherwise YAML parses as int (bytes) and
# topolvm rounds to its minimum (e.g. 300Mi), which won't hold kafka raft
# metadata and the broker crashes with "No space left on device" (bus5 实测).
_qty_re='^[0-9]+(\.[0-9]+)?(Ki|Mi|Gi|Ti|Pi|Ei)$'
[[ "$KAFKA_STORAGE_SIZE" =~ $_qty_re ]] || die "KAFKA_STORAGE_SIZE=\"$KAFKA_STORAGE_SIZE\" must carry a unit suffix (Mi/Gi/Ti), e.g. 100Gi"
[[ "$CK_STORAGE_SIZE"    =~ $_qty_re ]] || die "CK_STORAGE_SIZE=\"$CK_STORAGE_SIZE\" must carry a unit suffix (Mi/Gi/Ti), e.g. 300Gi"
[[ "${KAFKA_CONTROLLER_STORAGE_SIZE:-5Gi}" =~ $_qty_re ]] || die "KAFKA_CONTROLLER_STORAGE_SIZE=\"$KAFKA_CONTROLLER_STORAGE_SIZE\" must carry a unit suffix"
[[ "${KEEPER_STORAGE_SIZE:-10Gi}"          =~ $_qty_re ]] || die "KEEPER_STORAGE_SIZE=\"$KEEPER_STORAGE_SIZE\" must carry a unit suffix"

export NAMESPACE="${NAMESPACE:-cpaas-system}"

# OLM channel defaults — bus4/bus5 verified. Lets old install.env (without
# OLM_CHANNEL_* lines) still render a valid Subscription instead of channel="".
export OLM_CHANNEL_CK="${OLM_CHANNEL_CK:-stable}"
export OLM_CHANNEL_KAFKA="${OLM_CHANNEL_KAFKA:-stable}"
export OLM_CHANNEL_LOG_STORAGE="${OLM_CHANNEL_LOG_STORAGE:-alpha}"

export KEEPER_IMAGE="${KEEPER_IMAGE:-}"
export CK_SERVER_IMAGE="${CK_SERVER_IMAGE:-$KEEPER_IMAGE}"

# Resource name defaults (match install.env.example) so password derivation
# below has stable inputs even if the SRE wiped these from install.env.
KAFKA_NAME="${KAFKA_NAME:-cpaas-kafka}"
KAFKA_USER="${KAFKA_USER:-platform-logging}"
CK_NAME="${CK_NAME:-cpaas-clickhouse}"
CK_USER="${CK_USER:-admin}"

# Password auto-generation: empty → deterministic sha256-derived hex from
# stable inputs so re-runs produce the same password (idempotent). An
# explicitly set password in install.env wins.
if [[ -z "${KAFKA_SASL_PASSWORD:-}" ]]; then
  KAFKA_SASL_PASSWORD="$(printf '%s' "${NAMESPACE}|kafka|${KAFKA_NAME}|${KAFKA_USER}" | sha256sum | awk '{print $1}' | cut -c1-40)"
  log "KAFKA_SASL_PASSWORD empty → auto-generated 40-hex: $KAFKA_SASL_PASSWORD"
fi
export KAFKA_SASL_PASSWORD
if [[ -z "${CK_ADMIN_PASSWORD:-}" ]]; then
  CK_ADMIN_PASSWORD="$(printf '%s' "${NAMESPACE}|ch|${CK_NAME}|${CK_USER}" | sha256sum | awk '{print $1}' | cut -c1-32)"
  log "CK_ADMIN_PASSWORD empty → auto-generated 32-hex: $CK_ADMIN_PASSWORD"
fi
export CK_ADMIN_PASSWORD

if [[ ${#KAFKA_SASL_PASSWORD} -lt 32 ]]; then
  warn "KAFKA_SASL_PASSWORD is ${#KAFKA_SASL_PASSWORD} chars (< 32). KafkaUser may be rejected on MicroOS FIPS hosts."
fi

# Topic replication factor = min(3, KAFKA_REPLICAS).
KAFKA_REPLICAS=1  # single-node PoC: do not override
if (( KAFKA_REPLICAS < 3 )); then
  export KAFKA_TOPIC_REPLICATION="$KAFKA_REPLICAS"
else
  export KAFKA_TOPIC_REPLICATION=3
fi

# Kafka retention / segment time (ms). Defaults: 2d retention, 1d segment.
# PoC/demo can override to minutes; segment should be <= retention/2 or expired
# data lingers in the active segment past retention.
export KAFKA_RETENTION_MS="${KAFKA_RETENTION_MS:-172800000}"
export KAFKA_SEGMENT_MS="${KAFKA_SEGMENT_MS:-86400000}"
if (( KAFKA_SEGMENT_MS > KAFKA_RETENTION_MS )); then
  warn "KAFKA_SEGMENT_MS ($KAFKA_SEGMENT_MS) > KAFKA_RETENTION_MS ($KAFKA_RETENTION_MS); actual retention may be up to segment+retention. Prefer segment <= retention/2."
fi

# TLS listener is always on (templates/12-rdskafka.yaml opens both plain:9092
# and tls:9093). bootstrap goes to :9093 because operator's secret-bridge
# unconditionally injects strimzi cluster-ca-cert into mq-conn.tls.ca,
# which drives vector to speak sasl_ssl.
export KAFKA_PORT="9093"

# Precompute CK password sha256_hex (clickhouse requires lower-hex, 64 chars).
# Single-node PoC: hard-pin CK layout to 1 shard x 1 replica even if user
# edited install.env — anything larger would hit pod anti-affinity / topolvm
# node pinning on a 1-worker cluster.
if [[ "${CK_SHARDS:-1}" != "1" || "${CK_REPLICAS:-1}" != "1" ]]; then
  warn "CK_SHARDS=${CK_SHARDS:-1} CK_REPLICAS=${CK_REPLICAS:-1} overridden to 1/1 (single-node PoC)"
fi
export CK_SHARDS=1
export CK_REPLICAS=1

# AGGVEC / RAZOR replicas default to 1 for PoC; respect user override if any
export AGGVEC_REPLICAS="${AGGVEC_REPLICAS:-1}"
export RAZOR_REPLICAS="${RAZOR_REPLICAS:-1}"

export CK_PASSWORD_SHA256
CK_PASSWORD_SHA256="$(printf '%s' "$CK_ADMIN_PASSWORD" | sha256sum | awk '{print $1}')"

# Conn Secret names. Defaults match the historical quickstart convention so
# single-cluster installs stay zero-config. In a DR/active-standby topology
# etcd-sync replicates /registry/secrets/<ns>/<name> across the master+standby
# pair, so both sites must use DIFFERENT names here — otherwise the master's
# Secret overwrites the standby's and the standby's aggvec/razor end up with
# the wrong Kafka/CK credentials. See AIT-76469.
export MQ_CONN_SECRET_NAME="${MQ_CONN_SECRET_NAME:-platform-default-mq-conn}"
export CH_CONN_SECRET_NAME="${CH_CONN_SECRET_NAME:-platform-default-ch-conn}"

#--------------------------- helpers ------------------------------------------
# Render a template with envsubst — only the vars we know about, so stray
# $-expressions in heredocs (like `${HOSTNAME##*-}` in keeper command) survive.
render() {
  local tpl="$1"
  envsubst '
    ${NAMESPACE} ${STORAGE_CLASS}
    ${OLM_CHANNEL_CK} ${OLM_CHANNEL_KAFKA} ${OLM_CHANNEL_LOG_STORAGE}
    ${KAFKA_NAME} ${KAFKA_USER} ${KAFKA_REPLICAS} ${KAFKA_PORT}
    ${KAFKA_STORAGE_SIZE} ${KAFKA_CONTROLLER_STORAGE_SIZE}
    ${KAFKA_CPU_REQUEST} ${KAFKA_CPU_LIMIT} ${KAFKA_MEM_REQUEST} ${KAFKA_MEM_LIMIT}
    ${KAFKA_SASL_PASSWORD} ${KAFKA_PASSWORD_RESOLVED} ${KAFKA_TOPIC_REPLICATION}
    ${KAFKA_RETENTION_MS} ${KAFKA_SEGMENT_MS}
    ${CK_NAME} ${CK_USER} ${CK_ADMIN_PASSWORD} ${CK_PASSWORD_SHA256}
    ${CK_SHARDS} ${CK_REPLICAS} ${CK_STORAGE_SIZE}
    ${CK_CPU_REQUEST} ${CK_CPU_LIMIT} ${CK_MEM_REQUEST} ${CK_MEM_LIMIT}
    ${KEEPER_IMAGE} ${CK_SERVER_IMAGE} ${KEEPER_STORAGE_SIZE}
    ${AGGVEC_REPLICAS} ${RAZOR_REPLICAS}
    ${KEEPER_CPU_REQUEST} ${KEEPER_CPU_LIMIT} ${KEEPER_MEM_REQUEST} ${KEEPER_MEM_LIMIT}
    ${MQ_CONN_SECRET_NAME} ${CH_CONN_SECRET_NAME}
    ${TLS_CA_BLOCK}
  ' < "$tpl"
}

apply() {
  local tpl="$1"
  local base
  base="$(basename "$tpl")"
  local pre="$RENDER_DIR/$base"

  if is_render_only; then
    local rendered
    rendered="$(render "$tpl")"
    echo "$rendered" > "$pre"
    log "  wrote $pre"
    return 0
  fi

  # Live mode: prefer pre-rendered file if present. Lets SRE run --render
  # first, tweak YAML by hand (resources / labels / tunings), then re-run
  # live and have install.sh drive the stage order + wait + idempotence.
  # Missing files fall back to a fresh template render (so e.g. mq-conn —
  # which --render skips — is still produced on the fly with the live
  # strimzi cluster-ca-cert injected).
  if [[ -f "$pre" ]]; then
    # Guard against a pre-rendered file left over from a prior fallback render
    # (e.g. pre-MR!39 KEEPER placeholder, future similar fallbacks). Any
    # __REPLACE_WITH_*__ sentinel means the YAML is incomplete and must not
    # reach kubelet — fall through to a fresh render using live-discovered
    # values instead of applying the poisoned file.
    if grep -q '__REPLACE_WITH_[A-Z0-9_]*__' "$pre"; then
      warn "  $base in ./rendered/ contains an unresolved __REPLACE_WITH_*__ sentinel — ignoring it and re-rendering from template"
    else
      log "  apply $base (from ./rendered/, SRE-reviewed)"
      kubectl apply --server-side --force-conflicts -f "$pre"
      return
    fi
  fi
  local rendered
  rendered="$(render "$tpl")"
  log "  apply $base (rendered inline from template)"
  echo "$rendered" | kubectl apply --server-side --force-conflicts -f -
}

wait_rollout() { kubectl -n "$1" rollout status "$2" --timeout=300s; }

wait_csv_succeeded() {
  local ns="$1" prefix="$2"
  log "  wait CSV ${ns}/${prefix}* Succeeded"
  for _ in {1..120}; do
    local name phase
    while IFS='=' read -r name phase; do
      [[ -z "$name" ]] && continue
      if [[ "$name" == "$prefix"* && "$phase" == "Succeeded" ]]; then
        ok "  CSV $name Succeeded"
        return 0
      fi
    done < <(kubectl -n "$ns" get csv -o jsonpath='{range .items[*]}{.metadata.name}={.status.phase}{"\n"}{end}' 2>/dev/null || true)
    sleep 5
  done
  die "CSV ${ns}/${prefix}* never reached Succeeded; kubectl -n $ns get csv for details"
}

#--------------------------- stage 0 ------------------------------------------
stage0_operators() {
  log "Stage 0: 3 OLM Subscriptions (chop → cpaas-logging, strimzi → kafka-system, log-storage → $NAMESPACE)"
  apply "$TPL/00-subscriptions.yaml"
  is_render_only && return 0
  wait_csv_succeeded cpaas-logging  clickhouse-operator
  wait_csv_succeeded kafka-system   strimzi-kafka-operator
  wait_csv_succeeded "$NAMESPACE"   log-storage-operator
  wait_rollout cpaas-logging  deploy/clickhouse-operator       || true
  wait_rollout kafka-system   deploy/strimzi-cluster-operator  || true
  wait_rollout "$NAMESPACE"   deploy/log-storage-operator-controller-manager || true
  ok "Stage 0 PASS"
}

#--------------------------- stage 1a: keeper ---------------------------------
# chop runs in cpaas-logging — its Deployment carries CK_SERVER_IMAGE env.
# chop ships the env without the registry prefix(bus5 实测:env 只到
# `middleware/clickhouse-server:tag`,containerd 会去 docker.io 拉,内网
# 失败)。补回 chop container image 本身的 registry 段。
discover_keeper_image() {
  # Soft-fail (return 1, no stderr noise) so stage1a_keeper can fall back
  # to KEEPER_IMAGE from install.env.
  local img
  img="$(kubectl -n cpaas-logging get deploy clickhouse-operator \
    -o jsonpath='{.spec.template.spec.containers[?(@.name=="clickhouse-operator")].env[?(@.name=="CK_SERVER_IMAGE")].value}' 2>/dev/null || true)"
  [[ -n "$img" ]] || return 1
  # Detect missing registry: first path segment with no '.' or ':' = assume
  # Docker Hub namespace, prepend chop container image's registry.
  local first="${img%%/*}"
  if [[ "$first" != *.* && "$first" != *:* ]]; then
    local chop_img reg
    chop_img="$(kubectl -n cpaas-logging get deploy clickhouse-operator \
      -o jsonpath='{.spec.template.spec.containers[?(@.name=="clickhouse-operator")].image}' 2>/dev/null || true)"
    reg="${chop_img%%/*}"
    [[ -n "$reg" ]] || return 1
    img="${reg}/${img}"
  fi
  echo "$img"
}

stage1a_keeper() {
  log "Stage 1a: Keeper (single-node, 1-pod StatefulSet)"
  # Keeper image priority: install.env explicit > chop CSV probe.
  #
  # Render mode is 100% offline — if KEEPER_IMAGE is unset AND chop CSV isn't
  # yet reachable, SKIP ./rendered/10-keeper.yaml entirely (do NOT emit a
  # placeholder image, since a stale ./rendered/10-keeper.yaml would then be
  # picked up by a later live run and shipped to kubelet).
  # Live mode keeps the old hard failure.
  if [[ -z "${KEEPER_IMAGE:-}" ]]; then
    local probed=""
    probed="$(discover_keeper_image 2>/dev/null || true)"
    if [[ -n "$probed" ]]; then
      KEEPER_IMAGE="$probed"
      export KEEPER_IMAGE
      log "  keeper image (probed from chop CSV): $KEEPER_IMAGE"
    elif is_render_only; then
      warn "  render mode + KEEPER_IMAGE unset + chop CSV not reachable → SKIP ./rendered/10-keeper.yaml"
      warn "  (a rendered placeholder image would fail at kubelet with InvalidImageName)."
      warn "  To materialize keeper, either:"
      warn "    (a) set KEEPER_IMAGE in $ENV_FILE and re-run with --render, or"
      warn "    (b) kubectl apply ./rendered/00-subscriptions.yaml, wait chop CSV Succeeded,"
      warn "        then re-run this script in live mode (./install.sh install.env)."
      # Also drop any stale ./rendered/10-keeper.yaml left over from a previous
      # pre-MR!39 render — otherwise the next live run would pick it up blindly.
      [[ -f "$RENDER_DIR/10-keeper.yaml" ]] && rm -f "$RENDER_DIR/10-keeper.yaml" && \
        warn "  (removed stale $RENDER_DIR/10-keeper.yaml from a previous render)"
      ok "Stage 1a SKIPPED (render mode, no image available)"
      return 0
    else
      die "KEEPER_IMAGE unset and chop CSV not reachable. Either:
         (a) set KEEPER_IMAGE in $ENV_FILE to the clickhouse-server image
             your ACP release ships (see install.env.example for the format
             and the kubectl one-liner to look it up), or
         (b) first apply ./rendered/00-subscriptions.yaml, wait for the chop
             CSV to reach Succeeded, then re-run this script — Stage 1a will
             then probe the image automatically."
    fi
  else
    log "  keeper image (from $ENV_FILE): $KEEPER_IMAGE"
  fi
  apply "$TPL/10-keeper.yaml"
  is_render_only && return 0
  kubectl -n "$NAMESPACE" rollout status sts/keeper --timeout=600s
  ok "Stage 1a PASS"
}

#--------------------------- stage 1b: CH + Kafka -----------------------------
stage1b_dataplane() {
  # Ensure CK_SERVER_IMAGE is resolved — if user didn't set and it resolved to
  # empty earlier (KEEPER_IMAGE also empty at parse time), fall back to the
  # now-resolved KEEPER_IMAGE (populated by stage1a chop probe).
  if [[ -z "${CK_SERVER_IMAGE:-}" ]]; then
    export CK_SERVER_IMAGE="$KEEPER_IMAGE"
    log "  CK_SERVER_IMAGE defaulting to KEEPER_IMAGE: $CK_SERVER_IMAGE"
  fi
  log "Stage 1b: CHI + RdsKafka"
  apply "$TPL/11-chi.yaml"
  apply "$TPL/12-rdskafka.yaml"
  is_render_only && return 0

  log "  wait CHI ${CK_NAME} status.status=Completed"
  for _ in {1..120}; do
    local st
    st="$(kubectl -n "$NAMESPACE" get chi "$CK_NAME" -o jsonpath='{.status.status}' 2>/dev/null || true)"
    [[ "$st" == "Completed" ]] && break
    sleep 5
  done
  [[ "$st" == "Completed" ]] || die "CHI $NAMESPACE/$CK_NAME not Completed; kubectl -n $NAMESPACE describe chi/$CK_NAME"

  log "  wait kafka broker pods Ready"
  # Two-phase wait: strimzi reconcile 建 kafka/controller pods 慢于 RdsKafka
  # apply(bus5 实测约 20-60s)。`kubectl wait --for=condition=Ready pod -l ...`
  # 遇空 selector 立刻返回 `error: no matching resources found` 退出,**不等**
  # pods 出现。先 poll until exists,再 wait Ready。
  local sel="strimzi.io/cluster=$KAFKA_NAME,strimzi.io/kind=Kafka"
  for _ in {1..60}; do
    local cnt
    cnt="$(kubectl -n "$NAMESPACE" get pod -l "$sel" --no-headers 2>/dev/null | wc -l)"
    (( cnt >= 1 )) && break
    sleep 5
  done
  (( cnt >= 1 )) || die "no kafka pods appeared under selector $sel; kubectl -n $NAMESPACE describe rdskafka/$KAFKA_NAME"
  kubectl -n "$NAMESPACE" wait --for=condition=Ready pod \
    -l "$sel" --timeout=600s \
    || die "kafka pods not Ready; kubectl -n $NAMESPACE describe rdskafka/$KAFKA_NAME"

  # ACP CH ships with no built-in bootstrap of the `observability` database;
  # razor's startup probe pings it directly and crashloops if missing (per
  # docs.alauda.io/clickhouse/4.4/how_to/deploy_as_logging_storage.html).
  # Create it idempotently on the replicated cluster so razor / schema-
  # migrations Job can proceed without manual SRE intervention.
  log "  ensure database observability ON CLUSTER 'replicated' exists"
  local ck_pod
  ck_pod="$(kubectl -n "$NAMESPACE" get pod -l clickhouse.altinity.com/chi="$CK_NAME" \
    -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)"
  [[ -n "$ck_pod" ]] || die "cannot find CHI pod with label clickhouse.altinity.com/chi=$CK_NAME"
  kubectl -n "$NAMESPACE" exec "$ck_pod" -c clickhouse -- \
    clickhouse-client --user="$CK_USER" --password="$CK_ADMIN_PASSWORD" \
      --query "CREATE DATABASE IF NOT EXISTS observability ON CLUSTER 'replicated'" >/dev/null 2>&1 \
    || die "CREATE DATABASE observability failed on $NAMESPACE/$ck_pod"
  ok "Stage 1b PASS (observability database ready on all shards)"
}

#--------------------------- stage 2 ------------------------------------------
stage2_user_topics() {
  log "Stage 2: RdsKafkaUser + 3 RdsTopic"
  apply "$TPL/20-kafka-user-topics.yaml"
  is_render_only && return 0

  # Entity-operator provisions a user Secret with the same name as the KafkaUser.
  log "  wait strimzi-maintained secret/$KAFKA_USER"
  for _ in {1..60}; do
    kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1 && break
    sleep 5
  done
  kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1 \
    || die "KafkaUser-ref Secret $NAMESPACE/$KAFKA_USER not materialized"

  log "  wait 3 RdsTopic status.phase=Ready|Active (Alauda middleware fork)"
  for t in alauda-log-topic alauda-event-topic alauda-audit-topic; do
    for _ in {1..60}; do
      local phase
      phase="$(kubectl -n "$NAMESPACE" get rdstopic "$t" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
      [[ "$phase" == "Ready" || "$phase" == "Active" ]] && break
      sleep 5
    done
    [[ "$phase" == "Ready" || "$phase" == "Active" ]] || die "RdsTopic $NAMESPACE/$t phase=$phase (expect Ready|Active); kubectl -n $NAMESPACE describe rdstopic/$t"
  done
  ok "Stage 2 PASS"
}

#--------------------------- stage 3 ------------------------------------------
stage3_conn_secrets() {
  log "Stage 3: ${MQ_CONN_SECRET_NAME} + ${CH_CONN_SECRET_NAME} Secrets"
  # ch-conn has no external dependency — always render/apply in both modes.
  apply "$TPL/31-ch-conn-secret.yaml"

  # mq-conn.tls.ca MUST be populated — operator effectiveMessageQueueTarget()
  # reads mq-conn.data["tls.ca"] as the sole trigger to flip
  # kafkaTLSEnabled=true,which drives razor arg --kafka-tls-enabled and the
  # aggvec vector.toml tls.enabled. Empty tls.ca → operator thinks the broker
  # is PLAINTEXT and tells razor/aggvec to open plain socket to :9093,which
  # yields "unexpected EOF: broker appears to be expecting TLS" from the
  # TLS listener. bus5 实测验证。
  #
  # Render mode has no live cluster to read strimzi cluster-ca-cert from,so
  # the mq-conn Secret is OMITTED from ./rendered/ entirely. SRE flow:
  #   1) kubectl apply the rendered 00-10-11-12-20-31-40.yaml set
  #   2) wait Stage 1b (RdsKafka Ready) → strimzi creates cluster-ca-cert
  #   3) re-run `./install.sh install.env` live(without --render),Stage 3
  #      materializes mq-conn with tls.ca read from the live Secret
  if is_render_only; then
    log "  render mode: skip ${MQ_CONN_SECRET_NAME} (requires strimzi cluster-ca-cert,"
    log "              which only exists after RdsKafka Ready in live mode)"
    log "  → after applying ./rendered/*.yaml and reaching Stage 2 Ready, re-run"
    log "    this script WITHOUT --render to materialize mq-conn"
    ok "Stage 3 PASS (render: ch-conn only)"
    return 0
  fi

  # Live mode: read strimzi ${KAFKA_NAME}-cluster-ca-cert.data["ca.crt"] and
  # embed it into mq-conn.
  export KAFKA_PASSWORD_RESOLVED="${KAFKA_SASL_PASSWORD}"
  local ca_b64 ca_pem
  ca_b64="$(kubectl -n "$NAMESPACE" get secret "${KAFKA_NAME}-cluster-ca-cert" \
    -o jsonpath='{.data.ca\.crt}' 2>/dev/null || true)"
  [[ -n "$ca_b64" ]] || die "cluster CA secret ${KAFKA_NAME}-cluster-ca-cert not found; strimzi should have created it after RdsKafka Ready"
  ca_pem="$(printf '%s' "$ca_b64" | base64 -d | sed 's/^/    /')"
  export TLS_CA_BLOCK=$'  tls.ca: |\n'"$ca_pem"
  apply "$TPL/30-mq-conn-secret.yaml"
  ok "Stage 3 PASS"
}

#--------------------------- stage 4 ------------------------------------------
stage4_plf() {
  log "Stage 4: PlatformLogForward"
  # bus5 实测:operator pt E auto-migration(AutoMigrationRunnable
  # retry-until-converged)在 Stage 0 CSV Succeeded 后立刻 derive-plf,探到
  # Stage 1b 刚建的 CHI + RdsKafka,派生 installMode=Adopt + output.type=
  # clickhouse 的 AdoptCK PLF —— 等 Stage 4 跑到时 PLF 已存在。installMode 字段
  # CEL immutable(决策 #34),Fresh→Adopt 变更被拒。AdoptCK 场景 operator 对
  # install.sh 装的 CHI/Kafka 行为与 FreshCK 等价(都派生 aggvec / razor /
  # schema-migrations / Feature/log-center),所以若 PLF 已存在就 skip apply
  # 直接 wait Ready;不存在才 apply 自己的 Fresh 版本。
  if is_render_only || ! kubectl get plf platform-default >/dev/null 2>&1; then
    apply "$TPL/40-plf.yaml"
  else
    local mode scenario
    mode="$(kubectl get plf platform-default -o jsonpath='{.spec.installMode}' 2>/dev/null || true)"
    scenario="$(kubectl get plf platform-default -o jsonpath='{.status.scenario}' 2>/dev/null || true)"
    log "  PLF already exists (installMode=$mode scenario=$scenario); skip apply, just wait Ready"
  fi
  is_render_only && return 0
  log "  wait PLF Ready=True"
  for _ in {1..120}; do
    local ready
    ready="$(kubectl get plf platform-default \
      -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
    [[ "$ready" == "True" ]] && { ok "Stage 4 PASS"; return 0; }
    sleep 5
  done
  die "PLF platform-default never reached Ready=True; kubectl describe plf platform-default"
}

#--------------------------- go -----------------------------------------------
if is_render_only; then
  log "mode: --render (writes YAML to $RENDER_DIR, nothing applied)"
else
  log "mode: live apply to NAMESPACE=$NAMESPACE"
fi
log "        CK=$CK_NAME shards=$CK_SHARDS replicas=$CK_REPLICAS  storage=$STORAGE_CLASS"
log "        Kafka=$KAFKA_NAME replicas=$KAFKA_REPLICAS user=$KAFKA_USER"

stage0_operators
stage1a_keeper
stage1b_dataplane
stage2_user_topics
stage3_conn_secrets
stage4_plf

if is_render_only; then
  log "YAML files written to $RENDER_DIR (apply in filename order):"
  for f in "$RENDER_DIR"/*.yaml; do
    [[ -f "$f" ]] && printf "    %s\n" "$(basename "$f")"
  done
  log ""
  log "NOTE: ./rendered/ is NOT a complete install bundle on its own:"
  log "  * ${MQ_CONN_SECRET_NAME} Secret is OMITTED (needs live strimzi"
  log "    cluster-ca-cert, which only exists after RdsKafka is Ready)."
  log "  * 10-keeper.yaml is SKIPPED when KEEPER_IMAGE is unset and chop CSV"
  log "    isn't reachable (keeper image can only be resolved against a live cluster)."
  log ""
  log "Correct next step — re-run live (no --render):"
  log "    ./install.sh install.env"
  log "This re-reads ./rendered/* per stage (your edits honoured), mints"
  log "mq-conn with the live strimzi CA, waits each stage Ready, idempotent."
else
  ok "ALL STAGES PASS. Verify with ./check.sh install.env."
fi
