#!/usr/bin/env bash
# =============================================================================
# check.sh — acceptance verifier for the one-shot install
#
#   ./check.sh install.env            # runs all checks, exits 0 if ALL PASS
#
# Checks (in order):
#   1. PLF platform-default Ready=True
#   2. CHI <CK_NAME> status.status=Completed
#   3. 3 × RdsTopic (log/event/audit) status.phase=Ready
#   4. KafkaUser-ref Secret <KAFKA_USER> exists
#   5. aggregate-vector Deployment Available
#   6. razor Deployment Available
#   7. aggregate-vector / razor pods Running
#   8. schema-migrations Job(s) all Complete
# =============================================================================
set -Eeuo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; RST=$'\e[0m'
else
  BOLD=''; RED=''; GRN=''; YLW=''; RST=''
fi
pass() { printf "%s[check] ✓%s %s\n" "$GRN" "$RST" "$*"; }
fail() { printf "%s[check] ✗%s %s\n" "$RED" "$RST" "$*"; FAILED=$((FAILED+1)); }
info() { printf "%s[check]%s %s\n"   "$BOLD" "$RST" "$*"; }

#--------------------------- env ----------------------------------------------
[[ $# -ge 1 ]] || { echo "usage: $0 install.env" >&2; exit 2; }
ENV_FILE="$1"
[[ -r "$ENV_FILE" ]] || { echo "cannot read $ENV_FILE" >&2; exit 2; }
# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

NAMESPACE="${NAMESPACE:-cpaas-system}"
KAFKA_NAME="${KAFKA_NAME:-cpaas-kafka}"
KAFKA_USER="${KAFKA_USER:-platform-logging}"
CK_NAME="${CK_NAME:-cpaas-clickhouse}"
PLF_NAME="${PLF_NAME:-platform-default}"

FAILED=0

#--------------------------- 1. PLF Ready -------------------------------------
info "1. PLF/$PLF_NAME Ready"
ready="$(kubectl get plf "$PLF_NAME" -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
if [[ "$ready" == "True" ]]; then
  pass "PLF $PLF_NAME Ready=True"
else
  fail "PLF $PLF_NAME Ready=$ready (expected True)"
  kubectl get plf "$PLF_NAME" -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}' 2>/dev/null | sed 's/^/        /' || true
  echo
fi

#--------------------------- 2. CHI Completed ---------------------------------
info "2. CHI/$CK_NAME status.status=Completed"
chi_status="$(kubectl -n "$NAMESPACE" get chi "$CK_NAME" -o jsonpath='{.status.status}' 2>/dev/null || true)"
if [[ "$chi_status" == "Completed" ]]; then
  pass "CHI $NAMESPACE/$CK_NAME Completed"
else
  fail "CHI $NAMESPACE/$CK_NAME status.status=$chi_status (expected Completed)"
fi

#--------------------------- 3. RdsTopic Ready --------------------------------
info "3. 3 RdsTopic status.phase=Ready|Active"
for t in alauda-log-topic alauda-event-topic alauda-audit-topic; do
  phase="$(kubectl -n "$NAMESPACE" get rdstopic "$t" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
  if [[ "$phase" == "Ready" || "$phase" == "Active" ]]; then
    pass "RdsTopic $t $phase"
  else
    fail "RdsTopic $t phase=$phase (expected Ready or Active)"
  fi
done

#--------------------------- 4. KafkaUser Secret ------------------------------
info "4. KafkaUser-ref Secret/$KAFKA_USER exists"
if kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1; then
  pass "Secret $NAMESPACE/$KAFKA_USER present"
else
  fail "Secret $NAMESPACE/$KAFKA_USER missing"
fi

#--------------------------- 5-6. Deployments Available -----------------------
info "5-6. aggregate-vector / razor Deployments Available"
for d in aggregate-vector razor; do
  avail="$(kubectl -n "$NAMESPACE" get deploy "$d" -o jsonpath='{.status.conditions[?(@.type=="Available")].status}' 2>/dev/null || true)"
  if [[ "$avail" == "True" ]]; then
    pass "Deployment $d Available"
  else
    fail "Deployment $d Available=$avail (expected True)"
  fi
done

#--------------------------- 7. Pods Running ----------------------------------
info "7. aggregate-vector / razor pods Running"
not_running="$(kubectl -n "$NAMESPACE" get pod \
  -l 'app in (aggregate-vector,razor)' \
  -o jsonpath='{range .items[?(@.status.phase!="Running")]}{.metadata.name}={.status.phase} {end}' 2>/dev/null || true)"
if [[ -z "$not_running" ]]; then
  running_count="$(kubectl -n "$NAMESPACE" get pod -l 'app in (aggregate-vector,razor)' --no-headers 2>/dev/null | wc -l)"
  pass "$running_count aggvec/razor pods all Running"
else
  fail "non-Running pods: $not_running"
fi

#--------------------------- 8. schema-migrations Jobs Complete ---------------
info "8. schema-migrations Job(s) Complete"
jobs="$(kubectl -n "$NAMESPACE" get job -l 'app.kubernetes.io/name=schema-migrations' -o name 2>/dev/null || true)"
if [[ -z "$jobs" ]]; then
  fail "no schema-migrations Job found (expected ≥1)"
else
  while IFS= read -r j; do
    [[ -z "$j" ]] && continue
    done_cond="$(kubectl -n "$NAMESPACE" get "$j" -o jsonpath='{.status.conditions[?(@.type=="Complete")].status}' 2>/dev/null || true)"
    if [[ "$done_cond" == "True" ]]; then
      pass "$j Complete"
    else
      fail "$j Complete=$done_cond"
    fi
  done <<< "$jobs"
fi

#--------------------------- verdict ------------------------------------------
echo
if [[ "$FAILED" -eq 0 ]]; then
  printf "%s[check] ALL PASS%s\n" "$GRN" "$RST"
  exit 0
else
  printf "%s[check] %d check(s) FAILED%s\n" "$RED" "$FAILED" "$RST"
  exit 1
fi
