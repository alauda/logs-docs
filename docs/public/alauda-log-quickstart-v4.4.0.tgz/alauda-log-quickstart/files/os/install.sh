#!/usr/bin/env bash
# =============================================================================
# log-storage-operator one-shot install helper — OpenSearch backend
#
#   ./install.sh install.env            # live apply end to end; if ./rendered/
#                                       # already exists each stage reads from
#                                       # there so SRE edits survive.
#   ./install.sh install.env --render   # render YAML into ./rendered/ (cwd),
#                                       # zero kubectl calls. Mq-conn / os-conn
#                                       # Secrets are OMITTED (need live
#                                       # strimzi CA / opster admin secret).
#
# Reads install.env, drives a 7-stage install:
#   0  3 OLM Subs (strimzi + opensearch-operator + log-storage-operator)
#   1  OpenSearchCluster (opster) + wait Ready + read admin credentials
#   2  RdsKafka + wait broker pods Ready
#   3  RdsKafkaUser + 3 RdsTopic + wait secret/topics
#   4  platform-default-mq-conn Secret (injects live strimzi cluster-ca-cert)
#   5  platform-default-os-conn Secret (uses opster-generated admin credentials)
#   6  PlatformLogForward (externalStorage.type=opensearch) + wait Ready=True
#
# Scope: OpenSearch backend, fresh install, single storage cluster.
# For ES → OS migration (legacy chart-alauda-log-center), use ./upgrade-from-es.sh.
# =============================================================================
set -Eeuo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL="$HERE/templates"

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; RST=$'\e[0m'
else BOLD=''; RED=''; GRN=''; YLW=''; RST=''; fi
log()  { printf "%s[os-install]%s %s\n"   "$BOLD" "$RST" "$*"; }
ok()   { printf "%s[os-install] ✓%s %s\n" "$GRN"  "$RST" "$*"; }
warn() { printf "%s[os-install] ! %s%s\n" "$YLW"  "$*"   "$RST"; }
die()  { printf "%s[os-install] ✗ %s%s\n" "$RED"  "$*"   "$RST" >&2; exit 1; }

#--------------------------- args + env file ----------------------------------
RENDER_MODE="false"
ENV_FILE=""
for arg in "$@"; do
  case "$arg" in
    --render)   RENDER_MODE="true" ;;
    -h|--help)  sed -n '2,25p' "$0"; exit 0 ;;
    -*)         die "unknown flag: $arg (usage: $0 install.env [--render])" ;;
    *)          [[ -z "$ENV_FILE" ]] && ENV_FILE="$arg" || die "unexpected positional arg: $arg" ;;
  esac
done
[[ -n "$ENV_FILE" ]] || die "usage: $0 install.env [--render]"
[[ -r "$ENV_FILE" ]] || die "cannot read $ENV_FILE"
# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

RENDER_DIR="$(pwd)/rendered"
is_render_only() { [[ "$RENDER_MODE" == "true" ]]; }
is_render_only && mkdir -p "$RENDER_DIR"

#--------------------------- validate -----------------------------------------
: "${STORAGE_CLASS:?STORAGE_CLASS must be set in $ENV_FILE}"
: "${KAFKA_STORAGE_SIZE:?KAFKA_STORAGE_SIZE must be set in $ENV_FILE (e.g. 100Gi)}"
: "${OS_STORAGE_SIZE:?OS_STORAGE_SIZE must be set in $ENV_FILE (e.g. 200Gi per node)}"

_qty_re='^[0-9]+(\.[0-9]+)?(Ki|Mi|Gi|Ti|Pi|Ei)$'
[[ "$KAFKA_STORAGE_SIZE" =~ $_qty_re ]] || die "KAFKA_STORAGE_SIZE=\"$KAFKA_STORAGE_SIZE\" must carry a unit suffix"
[[ "$OS_STORAGE_SIZE"    =~ $_qty_re ]] || die "OS_STORAGE_SIZE=\"$OS_STORAGE_SIZE\" must carry a unit suffix"
[[ "${KAFKA_CONTROLLER_STORAGE_SIZE:-5Gi}" =~ $_qty_re ]] || die "KAFKA_CONTROLLER_STORAGE_SIZE must carry a unit suffix"

NAMESPACE="${NAMESPACE:-cpaas-system}"

export OLM_CHANNEL_KAFKA="${OLM_CHANNEL_KAFKA:-stable}"
export OLM_CHANNEL_OPENSEARCH="${OLM_CHANNEL_OPENSEARCH:-alpha}"
export OLM_CHANNEL_LOG_STORAGE="${OLM_CHANNEL_LOG_STORAGE:-alpha}"

# Kafka
KAFKA_NAME="${KAFKA_NAME:-cpaas-kafka}"
KAFKA_USER="${KAFKA_USER:-platform-logging}"
KAFKA_REPLICAS="${KAFKA_REPLICAS:-3}"
export KAFKA_CONTROLLER_STORAGE_SIZE="${KAFKA_CONTROLLER_STORAGE_SIZE:-5Gi}"
export KAFKA_CPU_REQUEST="${KAFKA_CPU_REQUEST:-500m}"
export KAFKA_CPU_LIMIT="${KAFKA_CPU_LIMIT:-2}"
export KAFKA_MEM_REQUEST="${KAFKA_MEM_REQUEST:-2Gi}"
export KAFKA_MEM_LIMIT="${KAFKA_MEM_LIMIT:-4Gi}"

if [[ -z "${KAFKA_SASL_PASSWORD:-}" ]]; then
  KAFKA_SASL_PASSWORD="$(printf '%s' "${NAMESPACE}|kafka|${KAFKA_NAME}|${KAFKA_USER}" | sha256sum | awk '{print $1}' | cut -c1-40)"
  log "KAFKA_SASL_PASSWORD empty → auto-generated 40-hex"
fi
export KAFKA_SASL_PASSWORD
(( ${#KAFKA_SASL_PASSWORD} < 32 )) && warn "KAFKA_SASL_PASSWORD is ${#KAFKA_SASL_PASSWORD} chars (< 32). KafkaUser may be rejected on MicroOS FIPS hosts."

if (( KAFKA_REPLICAS < 3 )); then
  export KAFKA_TOPIC_REPLICATION="$KAFKA_REPLICAS"
else
  export KAFKA_TOPIC_REPLICATION=3
fi
export KAFKA_RETENTION_MS="${KAFKA_RETENTION_MS:-172800000}"
export KAFKA_SEGMENT_MS="${KAFKA_SEGMENT_MS:-86400000}"
(( KAFKA_SEGMENT_MS > KAFKA_RETENTION_MS )) && warn "KAFKA_SEGMENT_MS ($KAFKA_SEGMENT_MS) > KAFKA_RETENTION_MS ($KAFKA_RETENTION_MS); actual retention may exceed nominal. Prefer segment <= retention/2."
export KAFKA_PORT="9093"

# OpenSearch
export OS_NAME="${OS_NAME:-cpaas-opensearch}"
export OS_VERSION="${OS_VERSION:-3.7.0}"
export OS_REPLICAS="${OS_REPLICAS:-3}"
export OS_CPU_REQUEST="${OS_CPU_REQUEST:-1}"
export OS_CPU_LIMIT="${OS_CPU_LIMIT:-4}"
export OS_MEM_REQUEST="${OS_MEM_REQUEST:-4Gi}"
export OS_MEM_LIMIT="${OS_MEM_LIMIT:-8Gi}"
(( OS_REPLICAS >= 3 )) || die "OS_REPLICAS must be >= 3 (OpenSearch cluster_manager quorum); got $OS_REPLICAS"

# OpenSearch opt-in plugins. OS_PLUGINS_LIST is a space-separated list of
# plugin install URLs (or local file paths accessible from each OS pod).
# opster runs `opensearch-plugin install <item>` per node before OS starts;
# a failing install crashes the node (bus5 实测). analysis-ik for Chinese
# log-query (razor --es-loganalyzer=ik_smart) is the typical candidate but
# SRE must pre-mirror a valid zip to a reachable registry. Default empty
# → no pluginsList block rendered; razor log query with non-ASCII keywords
# will not resolve ik_smart until the plugin is installed out-of-band (see
# SRE_EXTERNAL_SETUP.md §3b.0).
OS_PLUGINS_LIST="${OS_PLUGINS_LIST:-}"
if [[ -n "$OS_PLUGINS_LIST" ]]; then
  OS_PLUGINS_BLOCK=$'    pluginsList:'
  for url in $OS_PLUGINS_LIST; do
    OS_PLUGINS_BLOCK+=$'\n      - "'"$url"'"'
  done
else
  OS_PLUGINS_BLOCK=""
fi
export OS_PLUGINS_BLOCK

# PLF knobs
export AGGVEC_REPLICAS="${AGGVEC_REPLICAS:-3}"
export RAZOR_REPLICAS="${RAZOR_REPLICAS:-2}"

# Conn Secret names. Defaults match the historical quickstart convention so
# single-cluster installs stay zero-config. In a DR/active-standby topology
# etcd-sync replicates /registry/secrets/<ns>/<name> across the master+standby
# pair, so both sites must use DIFFERENT names here — otherwise the master's
# Secret overwrites the standby's and the standby's aggvec/razor end up with
# the wrong Kafka/OS credentials. See AIT-76469.
export MQ_CONN_SECRET_NAME="${MQ_CONN_SECRET_NAME:-platform-default-mq-conn}"
export OS_CONN_SECRET_NAME="${OS_CONN_SECRET_NAME:-platform-default-os-conn}"

export NAMESPACE KAFKA_NAME KAFKA_USER KAFKA_REPLICAS

#--------------------------- scheduling blocks --------------------------------
# Same build_scheduling_block used by ck/ for consistent tolerations + nodeAffinity.
TOLERATION_EFFECT="${TOLERATION_EFFECT:-NoSchedule}"
build_scheduling_block() {
  local p="$1" out=""
  if [[ -n "${TOLERATION_KEY:-}" ]]; then
    out+="${p}tolerations:"$'\n'
    out+="${p}  - key: ${TOLERATION_KEY}"$'\n'
    out+="${p}    operator: Equal"$'\n'
    out+="${p}    value: \"${TOLERATION_VALUE:-}\""$'\n'
    out+="${p}    effect: ${TOLERATION_EFFECT}"$'\n'
    out+="${p}  - key: node-role.kubernetes.io/master"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
    out+="${p}  - key: node-role.kubernetes.io/control-plane"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
    # Also tolerate ACP's `node-role.alauda.io/infra` convention taint. ACP
    # labels + taints infra-pool nodes with this key by default (bus5 实测);
    # without this the scheduler rejects any pool node that also carries it
    # because install.env only takes one user-defined toleration. Operator
    # Exists keeps the toleration value-agnostic.
    out+="${p}  - key: node-role.alauda.io/infra"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
  else
    out+="${p}tolerations:"$'\n'
    out+="${p}  - operator: Exists"$'\n'
  fi
  if [[ -n "${NODE_AFFINITY_KEY:-}" ]]; then
    out+="${p}affinity:"$'\n'
    out+="${p}  nodeAffinity:"$'\n'
    out+="${p}    requiredDuringSchedulingIgnoredDuringExecution:"$'\n'
    out+="${p}      nodeSelectorTerms:"$'\n'
    out+="${p}        - matchExpressions:"$'\n'
    out+="${p}            - key: ${NODE_AFFINITY_KEY}"$'\n'
    out+="${p}              operator: In"$'\n'
    out+="${p}              values: [\"${NODE_AFFINITY_VALUE:-}\"]"$'\n'
  fi
  printf '%s' "$out"
}
export KAFKA_SCHEDULING_BLOCK OS_BOOTSTRAP_SCHEDULING_BLOCK OS_NODEPOOL_SCHEDULING_BLOCK
KAFKA_SCHEDULING_BLOCK="$(build_scheduling_block '        ')"             # strimzi (kafka|controller|entityOperator).template.pod
OS_BOOTSTRAP_SCHEDULING_BLOCK="$(build_scheduling_block '    ')"          # OpenSearchCluster.spec.bootstrap
OS_NODEPOOL_SCHEDULING_BLOCK="$(build_scheduling_block '      ')"         # OpenSearchCluster.spec.nodePools[0]

#--------------------------- helpers ------------------------------------------
render() {
  local tpl="$1"
  envsubst '
    ${NAMESPACE} ${STORAGE_CLASS}
    ${OLM_CHANNEL_KAFKA} ${OLM_CHANNEL_OPENSEARCH} ${OLM_CHANNEL_LOG_STORAGE}
    ${KAFKA_NAME} ${KAFKA_USER} ${KAFKA_REPLICAS} ${KAFKA_PORT}
    ${KAFKA_STORAGE_SIZE} ${KAFKA_CONTROLLER_STORAGE_SIZE}
    ${KAFKA_CPU_REQUEST} ${KAFKA_CPU_LIMIT} ${KAFKA_MEM_REQUEST} ${KAFKA_MEM_LIMIT}
    ${KAFKA_SASL_PASSWORD} ${KAFKA_TOPIC_REPLICATION}
    ${KAFKA_RETENTION_MS} ${KAFKA_SEGMENT_MS}
    ${OS_NAME} ${OS_VERSION} ${OS_REPLICAS} ${OS_STORAGE_SIZE}
    ${OS_CPU_REQUEST} ${OS_CPU_LIMIT} ${OS_MEM_REQUEST} ${OS_MEM_LIMIT}
    ${OS_ENDPOINTS} ${OS_USERNAME} ${OS_PASSWORD} ${OS_PLUGINS_BLOCK}
    ${AGGVEC_REPLICAS} ${RAZOR_REPLICAS}
    ${MQ_CONN_SECRET_NAME} ${OS_CONN_SECRET_NAME}
    ${TLS_CA_BLOCK}
    ${KAFKA_SCHEDULING_BLOCK} ${OS_BOOTSTRAP_SCHEDULING_BLOCK} ${OS_NODEPOOL_SCHEDULING_BLOCK}
  ' < "$tpl"
}

apply() {
  local tpl="$1" base pre rendered
  base="$(basename "$tpl")"
  pre="$RENDER_DIR/$base"

  if is_render_only; then
    rendered="$(render "$tpl")"
    printf '%s' "$rendered" > "$pre"
    log "  render → $pre"
    return 0
  fi

  if [[ -f "$pre" ]]; then
    log "  apply $base (from ./rendered/)"
    kubectl apply --server-side --force-conflicts -f "$pre" 2>&1 | sed 's/^/             /'
  else
    log "  apply $base (rendered inline from template)"
    render "$tpl" | kubectl apply --server-side --force-conflicts -f - 2>&1 | sed 's/^/             /'
  fi
}

wait_csv_succeeded() {
  local ns="$1" prefix="$2" max=120 i=0 csv phase
  while (( i < max )); do
    csv="$(kubectl -n "$ns" get csv -o name 2>/dev/null | awk -F/ "/\/${prefix}\./{print \$2; exit}")"
    if [[ -n "$csv" ]]; then
      phase="$(kubectl -n "$ns" get csv "$csv" -o jsonpath='{.status.phase}' 2>/dev/null)"
      [[ "$phase" == "Succeeded" ]] && { ok "  CSV $csv Succeeded"; return 0; }
    fi
    sleep 5; i=$((i + 1))
  done
  die "  CSV ${prefix}* in $ns did not reach Succeeded within 10 min"
}

# Check whether an OLM-installed operator for `pkg` already has a Succeeded CSV
# somewhere cluster-wide. Writes the first matching "<ns>/<name>" to stdout and
# returns 0 if present, 1 otherwise. Used by Stage 0 to idempotently skip the
# Subscription apply + CSV wait on clusters that already run a compatible
# operator (typical on brownfield upgrade paths — e.g. bus6 had strimzi 4.3.2
# preinstalled via an AllNamespaces OperatorGroup, which forbids a second
# Subscription in another namespace due to OLM InterOperatorGroupOwnerConflict).
operator_csv_present() {
  local pkg="$1"
  kubectl get csv -A -o jsonpath='{range .items[*]}{.metadata.namespace}/{.metadata.name}|{.status.phase}{"\n"}{end}' 2>/dev/null \
    | awk -F'|' -v pkg="$pkg" '
        {
          split($1, a, "/")
          name = a[2]
          # match "<pkg>.v<version>" exactly, not "<pkg>-<something>.v..." like
          # strimzi-kafka-operator-stable-platform-cpaas-system
          if (name ~ "^" pkg "\\.v[0-9]" && $2 == "Succeeded") { print $1; exit 0 }
        }'
}

approve_installplan_if_needed() {
  local ns="$1" sub="$2" ip
  ip="$(kubectl -n "$ns" get sub "$sub" -o jsonpath='{.status.installplan.name}' 2>/dev/null)"
  [[ -z "$ip" ]] && return 0
  local approved
  approved="$(kubectl -n "$ns" get installplan "$ip" -o jsonpath='{.spec.approved}' 2>/dev/null)"
  if [[ "$approved" != "true" ]]; then
    log "  approve InstallPlan $ns/$ip for Subscription $sub"
    kubectl -n "$ns" patch installplan "$ip" --type=merge -p '{"spec":{"approved":true}}' >/dev/null
  fi
}

wait_rollout() {
  kubectl -n "$1" rollout status "$2" --timeout=300s 2>&1 | sed 's/^/             /'
}

wait_opensearch_cluster() {
  local ns="$1" name="$2" max=240 i=0 phase health initd
  log "  wait OpenSearchCluster ${ns}/${name} phase=RUNNING + health=green + initialized (up to 20 min)"
  while (( i < max )); do
    phase="$(kubectl -n "$ns" get opensearchcluster "$name" -o jsonpath='{.status.phase}' 2>/dev/null)"
    health="$(kubectl -n "$ns" get opensearchcluster "$name" -o jsonpath='{.status.health}' 2>/dev/null)"
    initd="$(kubectl -n "$ns" get opensearchcluster "$name" -o jsonpath='{.status.initialized}' 2>/dev/null)"
    # Bus5 实测:phase=RUNNING + health="" 可以出现在 nodes-0 crash loop 时,
    # OS security 未 initialize,admin-password Secret 还是 bootstrap 的 admin/admin。
    # 必须等 health=green + initialized=true,此时 securityconfig-update Job 已经把
    # 真实 admin pw 写入 <OS_NAME>-admin-password,下 Stage 读到的才是最终凭据。
    if [[ "$phase" == "RUNNING" && "$health" == "green" && "$initd" == "true" ]]; then
      ok "  OpenSearchCluster $name RUNNING + green + initialized"; return 0
    fi
    if (( i > 0 && i % 12 == 11 )); then log "    still waiting (phase=$phase health=$health initialized=$initd, $((i*5/60)) min elapsed)"; fi
    sleep 5; i=$((i + 1))
  done
  die "  OpenSearchCluster $name not phase=RUNNING+health=green+initialized within 20 min; last status:
     phase=$phase health=$health initialized=$initd"
}

wait_opensearch_securityconfig() {
  local ns="$1"
  local cluster_name="$2"
  local job="${cluster_name}-securityconfig-update"
  log "  wait Job $ns/$job Complete (up to 5 min)"
  if kubectl -n "$ns" wait job "$job" --for=condition=Complete --timeout=300s 2>&1 | sed 's/^/    /'; then
    ok "  $job Complete"; return 0
  fi
  warn "  $job did not reach Complete in 5 min; Stage 1 may have raced the admin password rotation. Consider re-running install.sh to refresh the os-conn Secret."
  return 0
}

wait_plf_ready() {
  local ns="$1" name="$2"
  log "  wait PLF ${ns}/${name} Ready=True (up to 20 min)"
  if kubectl -n "$ns" wait platformlogforward "$name" --for=condition=Ready --timeout=1200s 2>&1 | grep -v '^$' | sed 's/^/    /'; then
    ok "  PLF $name Ready=True"; return 0
  fi
  warn "PLF $name not Ready after 20 min; last status:"
  kubectl -n "$ns" get platformlogforward "$name" -o jsonpath='{.status}{"\n"}' 2>/dev/null | head -c 1200
  return 1
}

#--------------------------- stage 0: OLM Subscriptions -----------------------
# For each of the 3 operators the stack needs, apply + wait only when there is
# no pre-existing Succeeded CSV on the cluster. Skipping install when the
# operator is already there avoids OG conflicts on brownfield clusters and
# makes re-runs fast.
stage0_operators() {
  log "Stage 0: ensure 3 operators are present (strimzi + opensearch-operator + log-storage-operator)"
  local existing

  # strimzi-kafka-operator
  if existing="$(operator_csv_present strimzi-kafka-operator)" && [[ -n "$existing" ]]; then
    ok "  strimzi-kafka-operator already Succeeded at $existing — skipping Subscription"
  else
    apply "$TPL/00-strimzi-subscription.yaml"
    is_render_only || wait_csv_succeeded kafka-system strimzi-kafka-operator
  fi

  # opensearch-operator (installPlanApproval=Manual — auto-approve first InstallPlan after apply)
  if existing="$(operator_csv_present opensearch-operator)" && [[ -n "$existing" ]]; then
    ok "  opensearch-operator already Succeeded at $existing — skipping Subscription"
  else
    apply "$TPL/50-opensearch-operator-subscription.yaml"
    if ! is_render_only; then
      local attempts=24 i=0
      while (( i < attempts )); do
        if kubectl -n opensearch-operator get sub opensearch-operator -o jsonpath='{.status.installplan.name}' 2>/dev/null | grep -q .; then
          approve_installplan_if_needed opensearch-operator opensearch-operator
          break
        fi
        sleep 5; i=$((i + 1))
      done
      wait_csv_succeeded opensearch-operator opensearch-operator
    fi
  fi

  # log-storage-operator (AllNamespaces mode in cpaas-system)
  if existing="$(operator_csv_present log-storage-operator)" && [[ -n "$existing" ]]; then
    ok "  log-storage-operator already Succeeded at $existing — skipping Subscription"
  else
    apply "$TPL/99-log-storage-subscription.yaml"
    is_render_only || wait_csv_succeeded "$NAMESPACE" log-storage-operator
  fi

  ok "Stage 0 PASS"
}

#--------------------------- stage 1: OpenSearchCluster -----------------------
stage1_opensearch_cluster() {
  log "Stage 1: OpenSearchCluster $NAMESPACE/$OS_NAME"
  apply "$TPL/51-opensearch-cluster.yaml"
  is_render_only && return 0
  wait_opensearch_cluster "$NAMESPACE" "$OS_NAME"
  wait_opensearch_securityconfig "$NAMESPACE" "$OS_NAME"

  # Read opster-generated admin credentials.
  local admin_secret="${OS_NAME}-admin-password"
  log "  read admin credentials from Secret ${NAMESPACE}/${admin_secret}"
  local max=24 i=0
  while (( i < max )); do
    OS_USERNAME="$(kubectl -n "$NAMESPACE" get secret "$admin_secret" -o jsonpath='{.data.username}' 2>/dev/null | base64 -d 2>/dev/null || true)"
    OS_PASSWORD="$(kubectl -n "$NAMESPACE" get secret "$admin_secret" -o jsonpath='{.data.password}' 2>/dev/null | base64 -d 2>/dev/null || true)"
    [[ -n "$OS_USERNAME" && -n "$OS_PASSWORD" ]] && break
    sleep 5; i=$((i + 1))
  done
  [[ -n "$OS_USERNAME" && -n "$OS_PASSWORD" ]] || die "could not read admin credentials from ${admin_secret}"
  export OS_USERNAME OS_PASSWORD
  # Primary endpoint = OS service DNS in cpaas-system; HTTPS always (opster security.tls.http.generate=true).
  export OS_ENDPOINTS="https://${OS_NAME}.${NAMESPACE}.svc:9200"
  ok "  admin credentials read (user=$OS_USERNAME, password length ${#OS_PASSWORD})"
  ok "Stage 1 PASS"
}

#--------------------------- stage 2: RdsKafka --------------------------------
stage2_kafka() {
  log "Stage 2: RdsKafka $NAMESPACE/$KAFKA_NAME"
  apply "$TPL/12-rdskafka.yaml"
  is_render_only && return 0
  local sel="strimzi.io/cluster=$KAFKA_NAME,strimzi.io/kind=Kafka"
  log "  wait kafka pods Ready"
  local cnt=0 i=0
  while (( i < 60 )); do
    cnt="$(kubectl -n "$NAMESPACE" get pod -l "$sel" --no-headers 2>/dev/null | wc -l)"
    (( cnt >= 1 )) && break
    sleep 5; i=$((i + 1))
  done
  (( cnt >= 1 )) || die "no kafka pods appeared under selector $sel"
  kubectl -n "$NAMESPACE" wait pod -l "$sel" --for=condition=Ready --timeout=600s 2>&1 | sed 's/^/             /' \
    || die "kafka pods not Ready"
  ok "Stage 2 PASS"
}

#--------------------------- stage 3: Kafka user + topics ---------------------
stage3_user_topics() {
  log "Stage 3: RdsKafkaUser + 3 RdsTopic"
  apply "$TPL/20-kafka-user-topics.yaml"
  is_render_only && return 0
  log "  wait strimzi-maintained secret/$KAFKA_USER"
  local max=60 i=0
  while (( i < max )); do
    kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1 && break
    sleep 5; i=$((i + 1))
  done
  kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1 || die "strimzi-maintained secret/$KAFKA_USER never appeared"
  log "  wait 3 RdsTopic status.phase=Ready|Active"
  for t in alauda-log-topic alauda-event-topic alauda-audit-topic; do
    local j=0
    while (( j < 60 )); do
      local p
      p="$(kubectl -n "$NAMESPACE" get rdstopic "$t" -o jsonpath='{.status.phase}' 2>/dev/null)"
      [[ "$p" == "Ready" || "$p" == "Active" ]] && break
      sleep 5; j=$((j + 1))
    done
  done
  ok "Stage 3 PASS"
}

#--------------------------- stage 4: mq-conn Secret --------------------------
stage4_mq_conn() {
  log "Stage 4: ${MQ_CONN_SECRET_NAME} Secret"
  if ! is_render_only; then
    # Read strimzi cluster CA so mq-conn.tls.ca is populated — operator
    # effectiveMessageQueueTarget uses mq-conn.data["tls.ca"] as the sole
    # trigger for kafkaTLSEnabled=true. Empty → aggvec hits SSL handshake
    # failure on the :9093 TLS listener (see ck/install.sh Stage D comment).
    local ca_secret="${KAFKA_NAME}-cluster-ca-cert"
    local max=24 i=0 ca_pem=""
    while (( i < max )); do
      ca_pem="$(kubectl -n "$NAMESPACE" get secret "$ca_secret" -o jsonpath='{.data.ca\.crt}' 2>/dev/null | base64 -d 2>/dev/null | sed 's/^/    /' || true)"
      [[ -n "$ca_pem" ]] && break
      sleep 5; i=$((i + 1))
    done
    [[ -n "$ca_pem" ]] || die "strimzi cluster-ca-cert (secret $ca_secret) not found within 2 min"
    export TLS_CA_BLOCK=$'  tls.ca: |\n'"$ca_pem"
  else
    export TLS_CA_BLOCK='  # tls.ca injected at live apply time from strimzi cluster-ca-cert'
  fi
  apply "$TPL/30-mq-conn-secret.yaml"
  ok "Stage 4 PASS"
}

#--------------------------- stage 5: os-conn Secret --------------------------
stage5_os_conn() {
  log "Stage 5: ${OS_CONN_SECRET_NAME} Secret"
  if is_render_only; then
    export OS_ENDPOINTS="${OS_ENDPOINTS:-<live-os-service-dns>}"
    export OS_USERNAME="${OS_USERNAME:-<admin-from-live-secret>}"
    export OS_PASSWORD="${OS_PASSWORD:-<admin-from-live-secret>}"
  fi
  apply "$TPL/60-os-conn-secret.yaml"
  ok "Stage 5 PASS"
}

#--------------------------- stage 6: PLF -------------------------------------
stage6_plf() {
  local tpl="${PLF_TEMPLATE:-$TPL/70-plf.yaml}"
  log "Stage 6: PlatformLogForward (externalStorage.type=opensearch) — $(basename "$tpl")"
  apply "$tpl"
  is_render_only && return 0
  wait_plf_ready "$NAMESPACE" platform-default || warn "Stage 6 PLF Ready wait returned non-zero; check status above"
  ok "Stage 6 PASS"
}

#--------------------------- pipeline -----------------------------------------
if is_render_only; then
  log "mode: --render (writes YAML to $RENDER_DIR, nothing applied)"
else
  log "mode: live apply to NAMESPACE=$NAMESPACE"
  log "       Kafka=$KAFKA_NAME replicas=$KAFKA_REPLICAS user=$KAFKA_USER"
  log "       OpenSearch=$OS_NAME replicas=$OS_REPLICAS"
fi

stage0_operators
stage1_opensearch_cluster
stage2_kafka
stage3_user_topics
stage4_mq_conn
stage5_os_conn
stage6_plf

if is_render_only; then
  log ""
  log "NOTE: ./rendered/ is NOT a complete install bundle on its own:"
  log "  * ${MQ_CONN_SECRET_NAME} is OMITTED (needs live strimzi cluster-ca-cert)"
  log "  * ${OS_CONN_SECRET_NAME} is OMITTED (needs opster-generated admin creds)"
  log ""
  log "Correct next step — re-run live (no --render):"
  log "    ./install.sh $ENV_FILE"
  log "re-reads ./rendered/* per stage (your edits honoured), mints both"
  log "Secrets with live data, waits each stage Ready, idempotent."
else
  ok "install complete — run ./check.sh $ENV_FILE to verify"
fi
