#!/usr/bin/env bash
# =============================================================================
# log-storage-operator ES → OS migration helper (phase 1 of 4)
#
#   ./upgrade-from-es.sh install.env            # live apply
#   ./upgrade-from-es.sh install.env --render   # render YAML to ./rendered/
#
# Scope — THIS SCRIPT COVERS PHASE 1 ONLY. It stands up the new OpenSearch
# data path alongside the legacy ES stack, and submits a PLF carrying the
# `log.alauda.io/legacy-es-upgrade=true` annotation that activates the
# operator's legacy-ES handling (razor2 / Service switchover, PVC-delete
# protection webhook, legacy-es-precapture Jobs, old-Kafka lag observer).
#
# After this script returns:
#   PHASE 2 — SRE uninstalls the `logcenter` plugin via the ACP management
#             console (SRE_LEGACY_ES_MIGRATION.md §5).
#   PHASE 3 — SRE observes operator switchover + legacy Kafka consumer-group
#             lag reaching zero (§6, §7).
#   PHASE 4 — SRE creates a LegacyESMigration CR + runs the user-supplied
#             data-migration tool pod (reads legacy ES PVCs → writes new
#             OpenSearch), then validates and cleans up (§8, §9).
#
# The operator's `legacy_es_upgrade` controller is the source of truth for
# what this annotation triggers; refer to:
#   ait/log-storage-operator/docs/es-upgrade/SRE_LEGACY_ES_MIGRATION.md
#
# This script delegates the 6-stage install pipeline to ./install.sh with a
# PLF_TEMPLATE override that points at the legacy-ES PLF variant.
# =============================================================================
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; GRN=$'\e[32m'; YLW=$'\e[33m'; RST=$'\e[0m'
else BOLD=''; GRN=''; YLW=''; RST=''; fi
log()  { printf "%s[es-upgrade]%s %s\n"   "$BOLD" "$RST" "$*"; }
ok()   { printf "%s[es-upgrade] ✓%s %s\n" "$GRN"  "$RST" "$*"; }
warn() { printf "%s[es-upgrade] ! %s%s\n" "$YLW"  "$*"   "$RST"; }

log "Phase 1: install new OS data path + PLF with legacy-es-upgrade annotation"
log "       legacy ES (chart-alauda-log-center) stays running throughout."

# Default KAFKA_NAME / OS_NAME are chosen to NOT collide with legacy
# chart-alauda-log-center resource names, which hard-code `cpaas-kafka` for the
# ES stack's own Kafka StatefulSet and `cpaas-elasticsearch` for ES. If the
# new (operator-managed) Kafka CR reuses the legacy name, the Alauda strimzi
# fork detects the StatefulSet name collision and sets
# `strimzi.io/pause-reconciliation=true` on the new Kafka CR, preventing new
# broker pods from being created. SRE can still override via install.env.
export KAFKA_NAME="${KAFKA_NAME:-cpaas-kafka-new}"
export OS_NAME="${OS_NAME:-cpaas-opensearch}"

# PLF template override — stage6_plf in install.sh picks this up.
export PLF_TEMPLATE="$HERE/templates/71u-plf-legacy-es.yaml"

# Delegate the whole 6-stage pipeline (stages 0-6) to install.sh.
"$HERE/install.sh" "$@"

# install.sh's trailing success line prints the generic "run check.sh" message
# which is still correct for this script (acceptance identical). Append the
# phase-2-to-4 roadmap so the SRE knows the migration is not done yet.
case " $* " in
  *" --render "*) exit 0 ;;        # no roadmap in render-only mode
esac
printf '\n'
log "=========================================================================="
log "Phase 1 COMPLETE — the new OpenSearch data path is live."
log ""
log "NEXT STEPS — follow SRE_LEGACY_ES_MIGRATION.md"
log ""
log "  §5  Uninstall \`logcenter\` plugin via the ACP management console."
log "      The PVC-delete-protection webhook refuses PVC/PV deletion until"
log "      Phase 4 acceptance passes."
log ""
log "  §6  Operator switches razor2 / Service traffic to the new OS. Observe"
log "      the switchover; new queries now hit OpenSearch while historical"
log "      ES data remains query-able through legacy Service until §9."
log ""
log "  §7  Wait for legacy Kafka consumer-group lag to reach zero. The"
log "      operator has started an old-Kafka lag observer; it does NOT"
log "      scale legacy pods, only records lag."
log ""
log "  §8  Create a LegacyESMigration CR and run the user-supplied data"
log "      migration tool pod (reads legacy ES PVCs → writes new OpenSearch)."
log "      Progress is reported on the CR's status.workers[]."
log ""
log "  §9  Acceptance (ledger-level reconciliation on indices) + rollback"
log "      window closure + PVC / PV manual cleanup after webhook releases."
log ""
log "This script does NOT attempt to automate phases 2-4. The migration flow"
log "is intentionally hand-driven: PVC lifecycle, data-migration tool image,"
log "and acceptance criteria are site-specific."
log "=========================================================================="
