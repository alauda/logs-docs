#!/usr/bin/env bash
# =============================================================================
# check.sh — acceptance verifier for the OpenSearch one-shot install
#
#   ./check.sh install.env            # runs all checks, exits 0 if ALL PASS
#
# Checks (in order):
#   1. PLF platform-default Ready=True
#   2. OpenSearchCluster <OS_NAME> status.phase=RUNNING + health!=red
#   3. 3 × RdsTopic (log/event/audit) status.phase=Ready|Active
#   4. KafkaUser-ref Secret <KAFKA_USER> exists
#   5. aggregate-vector / razor Deployments Available
#   6. aggregate-vector / razor pods Running
#   7. opensearch-index-init Job Complete
# =============================================================================
set -Eeuo pipefail

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; RED=$'\e[31m'; GRN=$'\e[32m'; RST=$'\e[0m'
else BOLD=''; RED=''; GRN=''; RST=''; fi
pass() { printf "%s[check] ✓%s %s\n" "$GRN" "$RST" "$*"; }
fail() { printf "%s[check] ✗%s %s\n" "$RED" "$RST" "$*"; FAILED=$((FAILED+1)); }
info() { printf "%s[check]%s %s\n"   "$BOLD" "$RST" "$*"; }

[[ $# -ge 1 ]] || { echo "usage: $0 install.env" >&2; exit 2; }
ENV_FILE="$1"
[[ -r "$ENV_FILE" ]] || { echo "cannot read $ENV_FILE" >&2; exit 2; }
# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

NAMESPACE="${NAMESPACE:-cpaas-system}"
KAFKA_USER="${KAFKA_USER:-platform-logging}"
OS_NAME="${OS_NAME:-cpaas-opensearch}"
PLF_NAME="${PLF_NAME:-platform-default}"

FAILED=0

info "1. PLF/$PLF_NAME Ready"
ready="$(kubectl get plf "$PLF_NAME" -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
if [[ "$ready" == "True" ]]; then
  pass "PLF $PLF_NAME Ready=True"
  # ES-upgrade variant: surface the legacy-es-upgrade annotation if present.
  ann="$(kubectl get plf "$PLF_NAME" -o jsonpath='{.metadata.annotations.log\.alauda\.io/legacy-es-upgrade}' 2>/dev/null || true)"
  if [[ "$ann" == "true" ]]; then
    info "    PLF carries log.alauda.io/legacy-es-upgrade=true — this is the ES → OS migration path"
    info "    acceptance of this check does NOT mean the migration is complete; follow SRE_LEGACY_ES_MIGRATION.md §5-§9"
  fi
else
  fail "PLF $PLF_NAME Ready=$ready (expected True)"
  kubectl get plf "$PLF_NAME" -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}' 2>/dev/null | sed 's/^/        /' || true
  echo
fi

info "2. OpenSearchCluster/$OS_NAME status.phase=RUNNING"
os_phase="$(kubectl -n "$NAMESPACE" get opensearchcluster "$OS_NAME" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
os_health="$(kubectl -n "$NAMESPACE" get opensearchcluster "$OS_NAME" -o jsonpath='{.status.health}' 2>/dev/null || true)"
if [[ "$os_phase" == "RUNNING" && "$os_health" != "red" ]]; then
  pass "OpenSearchCluster $NAMESPACE/$OS_NAME phase=$os_phase health=$os_health"
else
  fail "OpenSearchCluster $NAMESPACE/$OS_NAME phase=$os_phase health=$os_health (expected phase=RUNNING, health!=red)"
fi

info "3. 3 RdsTopic status.phase=Ready|Active"
for t in alauda-log-topic alauda-event-topic alauda-audit-topic; do
  phase="$(kubectl -n "$NAMESPACE" get rdstopic "$t" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
  if [[ "$phase" == "Ready" || "$phase" == "Active" ]]; then
    pass "RdsTopic $t $phase"
  else
    fail "RdsTopic $t phase=$phase (expected Ready or Active)"
  fi
done

info "4. KafkaUser-ref Secret/$KAFKA_USER exists"
if kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1; then
  pass "Secret $NAMESPACE/$KAFKA_USER present"
else
  fail "Secret $NAMESPACE/$KAFKA_USER missing"
fi

info "5. aggregate-vector / razor Deployments Available"
for d in aggregate-vector razor; do
  avail="$(kubectl -n "$NAMESPACE" get deploy "$d" -o jsonpath='{.status.conditions[?(@.type=="Available")].status}' 2>/dev/null || true)"
  if [[ "$avail" == "True" ]]; then
    pass "Deployment $d Available"
  else
    fail "Deployment $d Available=$avail (expected True)"
  fi
done

info "6. aggregate-vector / razor pods Running"
# Operator-managed pods carry `app.kubernetes.io/name=<aggregate-vector|razor>`.
not_running="$(kubectl -n "$NAMESPACE" get pod \
  -l 'app.kubernetes.io/name in (aggregate-vector,razor)' \
  -o jsonpath='{range .items[?(@.status.phase!="Running")]}{.metadata.name}={.status.phase} {end}' 2>/dev/null || true)"
running_count="$(kubectl -n "$NAMESPACE" get pod -l 'app.kubernetes.io/name in (aggregate-vector,razor)' --no-headers 2>/dev/null | wc -l)"
if [[ -z "$not_running" && "$running_count" -ge 2 ]]; then
  pass "$running_count aggvec/razor pods all Running"
elif [[ "$running_count" -lt 2 ]]; then
  fail "only $running_count aggvec/razor pods found (expected ≥ 2: one aggregate-vector + one razor)"
else
  fail "non-Running pods: $not_running"
fi

info "7. opensearch-index-init Job Complete"
job="opensearch-index-init"
if kubectl -n "$NAMESPACE" get job "$job" >/dev/null 2>&1; then
  done_cond="$(kubectl -n "$NAMESPACE" get job "$job" -o jsonpath='{.status.conditions[?(@.type=="Complete")].status}' 2>/dev/null || true)"
  if [[ "$done_cond" == "True" ]]; then
    pass "Job $job Complete"
  else
    fail "Job $job Complete=$done_cond"
  fi
else
  fail "Job $NAMESPACE/$job not found (expected: spawned by log-storage-operator reconciler on PLF create)"
fi

echo
if [[ "$FAILED" -eq 0 ]]; then
  printf "%s[check] ALL PASS%s\n" "$GRN" "$RST"
  exit 0
else
  printf "%s[check] %d check(s) FAILED%s\n" "$RED" "$FAILED" "$RST"
  exit 1
fi
