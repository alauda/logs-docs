# scripts/os — OpenSearch backend one-shot install / migration helpers

Scope: OpenSearch backend of the v4.4 logging stack (`log-storage-operator` +
`nevermore` + `razor` + `aggregate-vector`). ClickHouse backend lives in
`../ck/`.

## Files

| File | Purpose |
| --- | --- |
| `install.sh` | Fresh install. 7 stages: 3 OLM Subs → OpenSearchCluster → RdsKafka → user+topics → mq-conn Secret → os-conn Secret → PLF (externalStorage.type=opensearch). |
| `upgrade-from-es.sh` | ES → OS migration **phase 1 only**. Delegates stages 0-6 to `install.sh` with a PLF override that carries `log.alauda.io/legacy-es-upgrade=true`. Phases 2-4 are hand-driven per `SRE_LEGACY_ES_MIGRATION.md`. |
| `check.sh` | Post-install acceptance verifier. 7 checks (PLF Ready, OpenSearchCluster RUNNING + health non-red, 3 RdsTopic Ready, KafkaUser Secret, aggvec+razor Available, pods Running, opensearch-index-init Job Complete). |
| `install.env.example` | Sample env file. Copy to `install.env`, fill 3 required fields (`STORAGE_CLASS`, `KAFKA_STORAGE_SIZE`, `OS_STORAGE_SIZE`); every other field has a working default. |
| `templates/*.yaml` | CR manifests rendered by `install.sh` / `upgrade-from-es.sh` via `envsubst`. See the "Stage ↔ template map" below. |

## Run modes

Fresh OS install:
```
cp install.env.example install.env
# edit install.env — fill STORAGE_CLASS, KAFKA_STORAGE_SIZE, OS_STORAGE_SIZE
./install.sh install.env                 # live apply
./install.sh install.env --render        # render YAML to ./rendered/ (no apply)
./check.sh   install.env                 # acceptance verifier
```

ES → OS migration (phase 1 only — see `SRE_LEGACY_ES_MIGRATION.md` for phases 2-4):
```
cp install.env.example install.env
# edit install.env — same 3 required fields as fresh install
./upgrade-from-es.sh install.env         # live apply — new OS data path + PLF with legacy-es annotation
./check.sh install.env                   # verify the new data path is Ready
# Then follow SRE_LEGACY_ES_MIGRATION.md §5-§9 (console uninstall of logcenter,
# operator switchover observation, LegacyESMigration CR + user migration tool,
# acceptance + PVC cleanup).
```

## Stage ↔ template map

| Stage | Template | Both scripts? |
| --- | --- | --- |
| 0a | `templates/00-strimzi-subscription.yaml` | yes |
| 0b | `templates/50-opensearch-operator-subscription.yaml` | yes |
| 0c | `templates/99-log-storage-subscription.yaml` | yes |
| 1 | `templates/51-opensearch-cluster.yaml` | yes |
| 2 | `templates/12-rdskafka.yaml` | yes |
| 3 | `templates/20-kafka-user-topics.yaml` | yes |
| 4 | `templates/30-mq-conn-secret.yaml` (injects live strimzi CA at apply time) | yes |
| 5 | `templates/60-os-conn-secret.yaml` (fills in opster-generated admin creds) | yes |
| 6 | `templates/70-plf.yaml` **or** `templates/71u-plf-legacy-es.yaml` | install.sh / upgrade-from-es.sh |

## Idempotence

Both scripts are safe to re-run:
- `kubectl apply` is server-side; identical content produces no resourceVersion bump.
- Password derivation is `sha256sum` of stable inputs when `KAFKA_SASL_PASSWORD` is empty.
- OpenSearch admin password is READ (not generated) — re-reads produce the same value.
- Every wait gate short-circuits when the readiness condition already holds.

A mid-run failure → fix the condition → re-run. Already-complete stages pass instantly.

## Jump host requirements

`kubectl` + a kubeconfig that can reach the target cluster, plus `bash`,
`envsubst`, `base64`, `sha256sum` (all standard on Linux distributions).

## References

- `../ck/README.md` — ClickHouse backend counterpart.
- `ait/log-storage-operator/docs/SRE_EXTERNAL_SETUP.md §3b` — production OpenSearch cluster setup (opensearch-k8s-operator + ISM policies + index templates).
- `ait/log-storage-operator/docs/es-upgrade/SRE_LEGACY_ES_MIGRATION.md` — authoritative 11-chapter manual for ES → OS/CK migration (phases 2-4).
- `ait/log-storage-operator/config/samples/quickstart_external_opensearch.yaml` — the PoC single-node OpenSearch sample this script's production 3-node variant evolved from.
