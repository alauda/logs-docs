#!/usr/bin/env bash
# =============================================================================
# log-storage-operator one-shot install helper — external ClickHouse mode
#
#   ./install.sh install.env            # apply end-to-end to the live cluster
#   ./install.sh install.env --render   # render YAML into ./rendered/ (no kubectl)
#
# Scope: customer-managed external ClickHouse (and their own Keeper/ZooKeeper).
#   We install:  strimzi (Kafka) + log-storage-operator + derived data plane
#   We DO NOT install:  clickhouse-operator, Keeper, CHI
#
# Stage pipeline:
#   0  2 OLM Subscriptions (strimzi + log-storage)
#   1  RdsKafka (3 broker + 3 controller by default)
#   2  RdsKafkaUser + 3 RdsTopic
#   3  mq-conn Secret + ch-conn Secret (ch-conn points at external CH)
#   4  PlatformLogForward Ready=True
#        → operator reconciles: schema-migrations Job against the external CH,
#          then creates aggregate-vector / razor Deployments.
#
# IDEMPOTENT HARD-CONTRACT:
#   Re-running with the SAME install.env on the SAME cluster is a no-op after
#   the first successful run (server-side apply + deterministic passwords +
#   short-circuit waits on readiness conditions).
#
# TLS: this iteration does NOT emit tls.ca / tls.insecure_skip_verify into
# platform-default-ch-conn. HTTPS endpoints with public CAs work out of the
# box (Go system trust store). Self-signed / internal-CA customers must either
# use plain HTTP or install the CA out-of-band into the data-plane pod trust
# stores. CA support will be added as a follow-up (install.env knob + conditional
# tls.ca block in 31-ch-conn-secret.yaml).
# =============================================================================
set -Eeuo pipefail

#--------------------------- paths & colour -----------------------------------
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL="$HERE/templates"

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; RST=$'\e[0m'
else
  BOLD=''; RED=''; GRN=''; YLW=''; RST=''
fi
log()  { printf "%s[one-shot]%s %s\n"             "$BOLD" "$RST" "$*"; }
ok()   { printf "%s[one-shot] ✓%s %s\n"           "$GRN"  "$RST" "$*"; }
warn() { printf "%s[one-shot] ! %s%s\n"           "$YLW"  "$*"   "$RST"; }
die()  { printf "%s[one-shot] ✗ %s%s\n"           "$RED"  "$*"   "$RST" >&2; exit 1; }

#--------------------------- args + env file ----------------------------------
RENDER_MODE="false"
ENV_FILE=""
for arg in "$@"; do
  case "$arg" in
    --render)   RENDER_MODE="true" ;;
    -h|--help)  sed -n '2,25p' "$0"; exit 0 ;;
    -*)         die "unknown flag: $arg (usage: $0 install.env [--render])" ;;
    *)          [[ -z "$ENV_FILE" ]] && ENV_FILE="$arg" || die "unexpected positional arg: $arg" ;;
  esac
done
[[ -n "$ENV_FILE" ]] || die "usage: $0 install.env [--render]"
[[ -r "$ENV_FILE" ]] || die "cannot read $ENV_FILE"
# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

RENDER_DIR="$(pwd)/rendered"
is_render_only() { [[ "$RENDER_MODE" == "true" ]]; }
if is_render_only; then
  mkdir -p "$RENDER_DIR"
fi

#--------------------------- validate -----------------------------------------
: "${STORAGE_CLASS:?STORAGE_CLASS must be set in $ENV_FILE}"
: "${KAFKA_STORAGE_SIZE:?KAFKA_STORAGE_SIZE must be set in $ENV_FILE (e.g. 100Gi)}"
: "${CH_ENDPOINT:?CH_ENDPOINT must be set in $ENV_FILE (e.g. http://ck.customer.internal:8123)}"
: "${CH_PASSWORD:?CH_PASSWORD must be set in $ENV_FILE (CH does not accept anonymous access)}"

[[ "$CH_ENDPOINT" =~ ^https?:// ]] \
  || die "CH_ENDPOINT=\"$CH_ENDPOINT\" must start with http:// or https://"

_qty_re='^[0-9]+(\.[0-9]+)?(Ki|Mi|Gi|Ti|Pi|Ei)$'
[[ "$KAFKA_STORAGE_SIZE" =~ $_qty_re ]] || die "KAFKA_STORAGE_SIZE=\"$KAFKA_STORAGE_SIZE\" must carry a unit suffix (Mi/Gi/Ti), e.g. 100Gi"
[[ "${KAFKA_CONTROLLER_STORAGE_SIZE:-5Gi}" =~ $_qty_re ]] || die "KAFKA_CONTROLLER_STORAGE_SIZE=\"$KAFKA_CONTROLLER_STORAGE_SIZE\" must carry a unit suffix"

NAMESPACE="${NAMESPACE:-cpaas-system}"

export OLM_CHANNEL_KAFKA="${OLM_CHANNEL_KAFKA:-stable}"
export OLM_CHANNEL_LOG_STORAGE="${OLM_CHANNEL_LOG_STORAGE:-alpha}"

# Resource / CH default propagation so password derivation + templates have
# stable inputs even if the SRE wiped these from install.env.
KAFKA_NAME="${KAFKA_NAME:-cpaas-kafka}"
KAFKA_USER="${KAFKA_USER:-platform-logging}"

# CH_USER is intentionally not configurable — see install.env.example for why.
# install.env's value (if any) is ignored.
export CH_USER="admin"
export CH_DATABASE="${CH_DATABASE:-observability}"
export CH_CLUSTER="${CH_CLUSTER:-replicated}"
export CH_SHARDS="${CH_SHARDS:-1}"
export CH_REPLICAS="${CH_REPLICAS:-3}"
export CH_ENDPOINT CH_PASSWORD

# Kafka password auto-generation (same formula as ck/).
if [[ -z "${KAFKA_SASL_PASSWORD:-}" ]]; then
  KAFKA_SASL_PASSWORD="$(printf '%s' "${NAMESPACE}|kafka|${KAFKA_NAME}|${KAFKA_USER}" | sha256sum | awk '{print $1}' | cut -c1-40)"
  log "KAFKA_SASL_PASSWORD empty → auto-generated 40-hex: $KAFKA_SASL_PASSWORD"
fi
export KAFKA_SASL_PASSWORD

if [[ ${#KAFKA_SASL_PASSWORD} -lt 32 ]]; then
  warn "KAFKA_SASL_PASSWORD is ${#KAFKA_SASL_PASSWORD} chars (< 32). KafkaUser may be rejected on MicroOS FIPS hosts."
fi

# Topic replication factor = min(3, KAFKA_REPLICAS).
KAFKA_REPLICAS="${KAFKA_REPLICAS:-3}"
if (( KAFKA_REPLICAS < 3 )); then
  export KAFKA_TOPIC_REPLICATION="$KAFKA_REPLICAS"
else
  export KAFKA_TOPIC_REPLICATION=3
fi

export KAFKA_RETENTION_MS="${KAFKA_RETENTION_MS:-172800000}"
export KAFKA_SEGMENT_MS="${KAFKA_SEGMENT_MS:-86400000}"
if (( KAFKA_SEGMENT_MS > KAFKA_RETENTION_MS )); then
  warn "KAFKA_SEGMENT_MS ($KAFKA_SEGMENT_MS) > KAFKA_RETENTION_MS ($KAFKA_RETENTION_MS); actual retention may be up to segment+retention. Prefer segment <= retention/2."
fi

# TLS listener always on — mq-conn gets strimzi cluster-ca-cert injected,
# aggvec/razor connect sasl_ssl to :9093.
export KAFKA_PORT="9093"

# Conn Secret names (same semantics as ck/).
export MQ_CONN_SECRET_NAME="${MQ_CONN_SECRET_NAME:-platform-default-mq-conn}"
export CH_CONN_SECRET_NAME="${CH_CONN_SECRET_NAME:-platform-default-ch-conn}"

#--------------------------- scheduling blocks --------------------------------
# External-CH mode only schedules Kafka pods; no Keeper, no CHI.
TOLERATION_EFFECT="${TOLERATION_EFFECT:-NoSchedule}"
build_scheduling_block() {
  local p="$1" out=""
  if [[ -n "${TOLERATION_KEY:-}" ]]; then
    out+="${p}tolerations:"$'\n'
    out+="${p}  - key: ${TOLERATION_KEY}"$'\n'
    out+="${p}    operator: Equal"$'\n'
    out+="${p}    value: \"${TOLERATION_VALUE:-}\""$'\n'
    out+="${p}    effect: ${TOLERATION_EFFECT}"$'\n'
    out+="${p}  - key: node-role.kubernetes.io/master"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
    out+="${p}  - key: node-role.kubernetes.io/control-plane"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
    out+="${p}  - key: node-role.alauda.io/infra"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
  else
    out+="${p}tolerations:"$'\n'
    out+="${p}  - operator: Exists"$'\n'
  fi
  if [[ -n "${NODE_AFFINITY_KEY:-}" ]]; then
    out+="${p}affinity:"$'\n'
    out+="${p}  nodeAffinity:"$'\n'
    out+="${p}    requiredDuringSchedulingIgnoredDuringExecution:"$'\n'
    out+="${p}      nodeSelectorTerms:"$'\n'
    out+="${p}        - matchExpressions:"$'\n'
    out+="${p}            - key: ${NODE_AFFINITY_KEY}"$'\n'
    out+="${p}              operator: In"$'\n'
    out+="${p}              values: [\"${NODE_AFFINITY_VALUE:-}\"]"$'\n'
  fi
  printf '%s' "$out"
}
export KAFKA_SCHEDULING_BLOCK
KAFKA_SCHEDULING_BLOCK="$(build_scheduling_block '        ')"    # (kafka|controller|entityOperator).template.pod

#--------------------------- helpers ------------------------------------------
# Render a template with envsubst — allowlist only the vars we know about,
# so stray $-expressions (none here, but keep the discipline) survive.
# Notice: no CK_*/KEEPER_* vars; CH_* instead.
render() {
  local tpl="$1"
  envsubst '
    ${NAMESPACE} ${STORAGE_CLASS}
    ${OLM_CHANNEL_KAFKA} ${OLM_CHANNEL_LOG_STORAGE}
    ${KAFKA_NAME} ${KAFKA_USER} ${KAFKA_REPLICAS} ${KAFKA_PORT}
    ${KAFKA_STORAGE_SIZE} ${KAFKA_CONTROLLER_STORAGE_SIZE}
    ${KAFKA_CPU_REQUEST} ${KAFKA_CPU_LIMIT} ${KAFKA_MEM_REQUEST} ${KAFKA_MEM_LIMIT}
    ${KAFKA_SASL_PASSWORD} ${KAFKA_PASSWORD_RESOLVED} ${KAFKA_TOPIC_REPLICATION}
    ${KAFKA_RETENTION_MS} ${KAFKA_SEGMENT_MS}
    ${CH_ENDPOINT} ${CH_USER} ${CH_PASSWORD} ${CH_DATABASE} ${CH_CLUSTER}
    ${CH_SHARDS} ${CH_REPLICAS}
    ${MQ_CONN_SECRET_NAME} ${CH_CONN_SECRET_NAME}
    ${TLS_CA_BLOCK}
    ${KAFKA_SCHEDULING_BLOCK}
  ' < "$tpl"
}

apply() {
  local tpl="$1"
  local base
  base="$(basename "$tpl")"
  local pre="$RENDER_DIR/$base"

  if is_render_only; then
    local rendered
    rendered="$(render "$tpl")"
    echo "$rendered" > "$pre"
    log "  wrote $pre"
    return 0
  fi

  if [[ -f "$pre" ]]; then
    if grep -q '__REPLACE_WITH_[A-Z0-9_]*__' "$pre"; then
      warn "  $base in ./rendered/ contains an unresolved __REPLACE_WITH_*__ sentinel — ignoring it and re-rendering from template"
    else
      log "  apply $base (from ./rendered/, SRE-reviewed)"
      kubectl apply --server-side --force-conflicts -f "$pre"
      return
    fi
  fi
  local rendered
  rendered="$(render "$tpl")"
  log "  apply $base (rendered inline from template)"
  echo "$rendered" | kubectl apply --server-side --force-conflicts -f -
}

wait_rollout() { kubectl -n "$1" rollout status "$2" --timeout=300s; }

wait_csv_succeeded() {
  local ns="$1" prefix="$2"
  log "  wait CSV ${ns}/${prefix}* Succeeded"
  for _ in {1..120}; do
    local name phase
    while IFS='=' read -r name phase; do
      [[ -z "$name" ]] && continue
      if [[ "$name" == "$prefix"* && "$phase" == "Succeeded" ]]; then
        ok "  CSV $name Succeeded"
        return 0
      fi
    done < <(kubectl -n "$ns" get csv -o jsonpath='{range .items[*]}{.metadata.name}={.status.phase}{"\n"}{end}' 2>/dev/null || true)
    sleep 5
  done
  die "CSV ${ns}/${prefix}* never reached Succeeded; kubectl -n $ns get csv for details"
}

#--------------------------- stage 0 ------------------------------------------
stage0_operators() {
  log "Stage 0: 2 OLM Subscriptions (strimzi → kafka-system, log-storage → $NAMESPACE)"
  apply "$TPL/00-subscriptions.yaml"
  is_render_only && return 0
  wait_csv_succeeded kafka-system   strimzi-kafka-operator
  wait_csv_succeeded "$NAMESPACE"   log-storage-operator
  wait_rollout kafka-system   deploy/strimzi-cluster-operator  || true
  wait_rollout "$NAMESPACE"   deploy/log-storage-operator-controller-manager || true
  ok "Stage 0 PASS"
}

#--------------------------- stage 1: kafka only ------------------------------
stage1_kafka() {
  log "Stage 1: RdsKafka (${KAFKA_REPLICAS} broker + ${KAFKA_REPLICAS} controller)"
  apply "$TPL/12-rdskafka.yaml"
  is_render_only && return 0

  log "  wait kafka broker pods Ready"
  local sel="strimzi.io/cluster=$KAFKA_NAME,strimzi.io/kind=Kafka"
  local cnt=0
  for _ in {1..60}; do
    cnt="$(kubectl -n "$NAMESPACE" get pod -l "$sel" --no-headers 2>/dev/null | wc -l)"
    (( cnt >= 1 )) && break
    sleep 5
  done
  (( cnt >= 1 )) || die "no kafka pods appeared under selector $sel; kubectl -n $NAMESPACE describe rdskafka/$KAFKA_NAME"
  kubectl -n "$NAMESPACE" wait --for=condition=Ready pod \
    -l "$sel" --timeout=600s \
    || die "kafka pods not Ready; kubectl -n $NAMESPACE describe rdskafka/$KAFKA_NAME"
  ok "Stage 1 PASS"
}

#--------------------------- stage 2 ------------------------------------------
stage2_user_topics() {
  log "Stage 2: RdsKafkaUser + 3 RdsTopic"
  apply "$TPL/20-kafka-user-topics.yaml"
  is_render_only && return 0

  log "  wait strimzi-maintained secret/$KAFKA_USER"
  for _ in {1..60}; do
    kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1 && break
    sleep 5
  done
  kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1 \
    || die "KafkaUser-ref Secret $NAMESPACE/$KAFKA_USER not materialized"

  log "  wait 3 RdsTopic status.phase=Ready|Active (Alauda middleware fork)"
  local phase=""
  for t in alauda-log-topic alauda-event-topic alauda-audit-topic; do
    for _ in {1..60}; do
      phase="$(kubectl -n "$NAMESPACE" get rdstopic "$t" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
      [[ "$phase" == "Ready" || "$phase" == "Active" ]] && break
      sleep 5
    done
    [[ "$phase" == "Ready" || "$phase" == "Active" ]] || die "RdsTopic $NAMESPACE/$t phase=$phase (expect Ready|Active); kubectl -n $NAMESPACE describe rdstopic/$t"
  done
  ok "Stage 2 PASS"
}

#--------------------------- stage 3 ------------------------------------------
stage3_conn_secrets() {
  log "Stage 3: ${MQ_CONN_SECRET_NAME} + ${CH_CONN_SECRET_NAME} Secrets"
  # ch-conn has no external dependency — always render/apply in both modes.
  # Points at the customer's CH; operator consumes endpoint/cluster/db/user/password.
  apply "$TPL/31-ch-conn-secret.yaml"

  if is_render_only; then
    log "  render mode: skip ${MQ_CONN_SECRET_NAME} (requires strimzi cluster-ca-cert,"
    log "              which only exists after RdsKafka Ready in live mode)"
    log "  → after applying ./rendered/*.yaml and reaching Stage 2 Ready, re-run"
    log "    this script WITHOUT --render to materialize mq-conn"
    ok "Stage 3 PASS (render: ch-conn only)"
    return 0
  fi

  export KAFKA_PASSWORD_RESOLVED="${KAFKA_SASL_PASSWORD}"
  local ca_b64 ca_pem
  ca_b64="$(kubectl -n "$NAMESPACE" get secret "${KAFKA_NAME}-cluster-ca-cert" \
    -o jsonpath='{.data.ca\.crt}' 2>/dev/null || true)"
  [[ -n "$ca_b64" ]] || die "cluster CA secret ${KAFKA_NAME}-cluster-ca-cert not found; strimzi should have created it after RdsKafka Ready"
  ca_pem="$(printf '%s' "$ca_b64" | base64 -d | sed 's/^/    /')"
  export TLS_CA_BLOCK=$'  tls.ca: |\n'"$ca_pem"
  apply "$TPL/30-mq-conn-secret.yaml"
  ok "Stage 3 PASS"
}

#--------------------------- stage 3.5: bootstrap observability database -----
# ACP CH ships with no built-in bootstrap of the `observability` database;
# both razor's startup probe AND the operator-derived schema-migrations Job
# assume it already exists. In ck/ and ck-single/ this is done by
# `clickhouse-client` exec on the in-cluster CHI pod. In external-CH mode we
# have no CHI pod to exec on, so we run a short Job in NAMESPACE that curls
# the customer CH endpoint and issues:
#   CREATE DATABASE IF NOT EXISTS ${CH_DATABASE} ON CLUSTER '${CH_CLUSTER}'
#
# CH_USER needs CREATE DATABASE privilege. If the customer's DBA created the
# database out-of-band, this step is a no-op (IF NOT EXISTS). If CH_USER lacks
# privilege, the Job fails — the install exits here with a clear message
# telling the customer SRE to create the database manually and re-run.
stage3_5_bootstrap_db() {
  is_render_only && return 0
  log "Stage 3.5: ensure database ${CH_DATABASE} ON CLUSTER '${CH_CLUSTER}' exists on external CH"

  # Pick a probe image. Priority:
  #   1. install.env explicit (CH_BOOTSTRAP_IMAGE) — SRE override for air-gapped.
  #   2. Probe the chop operator in cpaas-logging (if the SRE separately
  #      installed one) and reuse its CK_SERVER_IMAGE env → clickhouse-server
  #      image, which ships `clickhouse-client` for a clean CLI path.
  #   3. Derive from log-storage-operator pod's registry prefix:
  #      <registry>/ops/alpine:latest (ACP convention). Uses BusyBox wget.
  #   4. Hard fail with a clear message telling SRE to set CH_BOOTSTRAP_IMAGE.
  #
  # BOOTSTRAP_MODE selects the command shape: "clickhouse-client" or "wget".
  local BOOTSTRAP_MODE=""
  if [[ -n "${CH_BOOTSTRAP_IMAGE:-}" ]]; then
    # SRE-provided — assume wget path unless image name hints clickhouse
    [[ "$CH_BOOTSTRAP_IMAGE" == *clickhouse-server* ]] && BOOTSTRAP_MODE="clickhouse-client" || BOOTSTRAP_MODE="wget"
    log "  bootstrap image (from install.env): $CH_BOOTSTRAP_IMAGE (mode=$BOOTSTRAP_MODE)"
  else
    # Probe chop CSV in cpaas-logging
    local chop_reg chop_img
    chop_img="$(kubectl -n cpaas-logging get deploy clickhouse-operator \
      -o jsonpath='{.spec.template.spec.containers[?(@.name=="clickhouse-operator")].env[?(@.name=="CK_SERVER_IMAGE")].value}' 2>/dev/null || true)"
    chop_reg="$(kubectl -n cpaas-logging get deploy clickhouse-operator \
      -o jsonpath='{.spec.template.spec.containers[?(@.name=="clickhouse-operator")].image}' 2>/dev/null || true)"
    if [[ -n "$chop_img" && -n "$chop_reg" ]]; then
      # chop env has just `middleware/clickhouse-server:tag`; prepend chop's own registry
      local first="${chop_img%%/*}"
      if [[ "$first" != *.* && "$first" != *:* ]]; then
        local reg="${chop_reg%%/*}"
        chop_img="${reg}/${chop_img}"
      fi
      CH_BOOTSTRAP_IMAGE="$chop_img"
      BOOTSTRAP_MODE="clickhouse-client"
      log "  bootstrap image (chop CSV CK_SERVER_IMAGE): $CH_BOOTSTRAP_IMAGE (mode=clickhouse-client)"
    else
      # Fall back: derive alpine path from log-storage-operator image registry
      local op_img reg
      op_img="$(kubectl -n "$NAMESPACE" get deploy log-storage-operator-controller-manager \
        -o jsonpath='{.spec.template.spec.containers[?(@.name=="manager")].image}' 2>/dev/null || true)"
      reg="${op_img%%/*}"
      if [[ -n "$reg" && "$op_img" == */*/* ]]; then
        CH_BOOTSTRAP_IMAGE="${reg}/ops/alpine:latest"
        BOOTSTRAP_MODE="wget"
        log "  bootstrap image (derived <registry>/ops/alpine): $CH_BOOTSTRAP_IMAGE (mode=wget)"
      else
        die "Stage 3.5: cannot auto-select a bootstrap image.
             Set CH_BOOTSTRAP_IMAGE in $ENV_FILE to a pullable image that has
             either 'clickhouse-client' (preferred) or BusyBox 'wget'.
             Examples:
               CH_BOOTSTRAP_IMAGE=\"<your-registry>/middleware/clickhouse-server:v25.8\"
               CH_BOOTSTRAP_IMAGE=\"<your-registry>/ops/alpine:3.23\""
      fi
    fi
  fi

  # Build the SQL. ON CLUSTER is REQUIRED — without it CH creates the DB only
  # on the coordinator node; on other shard replicas the migration Job later
  # fails with UNKNOWN_DATABASE.
  local sql="CREATE DATABASE IF NOT EXISTS ${CH_DATABASE} ON CLUSTER '${CH_CLUSTER}'"
  local job_name="ck-external-bootstrap-db"

  # Delete any prior Job so Create is idempotent. Successful prior-run Jobs
  # may still be present if ttlSecondsAfterFinished has not yet fired.
  kubectl -n "$NAMESPACE" delete job "$job_name" --ignore-not-found --wait=true >/dev/null 2>&1 || true

  # Build a single-line shell script. To sidestep every YAML/shell quoting
  # pitfall (SQL has single quotes for ON CLUSTER; shell wrapper has doubles),
  # base64-encode the whole script and decode it inside the pod. alpine and
  # clickhouse-server images both ship base64 in /bin.
  local container_script
  if [[ "$BOOTSTRAP_MODE" == "clickhouse-client" ]]; then
    # clickhouse-server image: use clickhouse-client native TCP :9000 (always
    # present alongside HTTP :8123 on a standard CH listener config).
    container_script='set -e; host=$(echo "$CH_ENDPOINT" | sed -E "s#^https?://##; s#[:/].*##"); clickhouse-client --host="$host" --port=9000 --user="$CH_USER" --password="$CH_PASSWORD" --query "$SQL"; echo "CREATE DATABASE issued via clickhouse-client to $host:9000"'
  else
    # BusyBox wget path: POST SQL to the HTTP endpoint with basic auth.
    container_script='set -e; out=$(wget -q -O- --user="$CH_USER" --password="$CH_PASSWORD" --post-data="$SQL" "$CH_ENDPOINT/") || { ec=$?; echo "wget failed (exit $ec); server response: $out"; exit $ec; }; echo "CREATE DATABASE issued; server replied: [$out]"'
  fi
  local script_b64
  script_b64="$(printf '%s' "$container_script" | base64 -w0)"

  # Inline Job manifest. Secret-sourced env vars keep user/password/endpoint
  # out of the Job manifest text; SQL is passed via env too (base64-free, but
  # all single-quote-containing content lives in env not the YAML literal).
  # Note: double-quote YAML scalars for `value:` so YAML parses them cleanly;
  # the SQL's single quotes pass through a double-quoted YAML string fine.
  cat <<EOF | kubectl -n "$NAMESPACE" apply -f - >/dev/null
apiVersion: batch/v1
kind: Job
metadata:
  name: ${job_name}
  namespace: ${NAMESPACE}
  labels:
    log.alauda.io/managed-by: one-shot-installer
spec:
  backoffLimit: 3
  ttlSecondsAfterFinished: 300
  template:
    metadata:
      labels:
        log.alauda.io/managed-by: one-shot-installer
    spec:
      restartPolicy: OnFailure
      tolerations:
        - operator: Exists
      containers:
        - name: bootstrap
          image: ${CH_BOOTSTRAP_IMAGE}
          command: ["sh", "-c", "eval \"\$(echo \$SCRIPT_B64 | base64 -d)\""]
          env:
            - name: SCRIPT_B64
              value: "${script_b64}"
            - name: CH_ENDPOINT
              valueFrom:
                secretKeyRef:
                  name: ${CH_CONN_SECRET_NAME}
                  key: endpoint
            - name: CH_USER
              valueFrom:
                secretKeyRef:
                  name: ${CH_CONN_SECRET_NAME}
                  key: username
            - name: CH_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: ${CH_CONN_SECRET_NAME}
                  key: password
            - name: SQL
              value: "${sql}"
EOF

  log "  wait Job/${job_name} Complete"
  local phase=""
  for _ in {1..30}; do
    phase="$(kubectl -n "$NAMESPACE" get job "$job_name" \
      -o jsonpath='{.status.conditions[?(@.type=="Complete")].status}' 2>/dev/null || true)"
    [[ "$phase" == "True" ]] && { ok "Stage 3.5 PASS (database ${CH_DATABASE} ensured)"; return 0; }
    # Also fail-fast on Failed
    failed="$(kubectl -n "$NAMESPACE" get job "$job_name" \
      -o jsonpath='{.status.conditions[?(@.type=="Failed")].status}' 2>/dev/null || true)"
    [[ "$failed" == "True" ]] && break
    sleep 5
  done
  # Final diagnostic
  local pod_name log_tail
  pod_name="$(kubectl -n "$NAMESPACE" get pod -l job-name="$job_name" \
    -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)"
  [[ -n "$pod_name" ]] && log_tail="$(kubectl -n "$NAMESPACE" logs "$pod_name" --tail=10 2>&1 || true)"
  die "Stage 3.5 FAILED: Job ${job_name} did not complete.
       Likely causes:
         (a) CH_USER=\"${CH_USER}\" lacks CREATE DATABASE privilege on the customer CH.
             The customer CH DBA must either grant it, or manually run:
                CREATE DATABASE IF NOT EXISTS ${CH_DATABASE} ON CLUSTER '${CH_CLUSTER}'
             and then re-run this script (Stage 3.5 becomes a no-op).
         (b) CH_ENDPOINT unreachable from cpaas-system pods (NetworkPolicy, firewall, DNS).
         (c) CH_CLUSTER \"${CH_CLUSTER}\" not present in customer's system.clusters.
         (d) CH_BOOTSTRAP_IMAGE=\"${CH_BOOTSTRAP_IMAGE}\" cannot be pulled, or its wget
             lacks --user/--password. Override CH_BOOTSTRAP_IMAGE in install.env.
       Job pod log tail:
${log_tail}"
}

#--------------------------- stage 4 ------------------------------------------
stage4_plf() {
  log "Stage 4: PlatformLogForward"
  apply "$TPL/40-plf.yaml"
  is_render_only && return 0
  log "  wait PLF Ready=True (operator runs schema-migrations against $CH_ENDPOINT)"
  local ready=""
  for _ in {1..120}; do
    ready="$(kubectl get plf platform-default \
      -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
    [[ "$ready" == "True" ]] && { ok "Stage 4 PASS"; return 0; }
    sleep 5
  done
  die "PLF platform-default never reached Ready=True; kubectl describe plf platform-default
       Common causes when connecting to external CH:
         - CH_ENDPOINT unreachable from cpaas-system pods (NetworkPolicy, firewall, DNS)
         - CH_USER lacks CREATE DATABASE / CREATE TABLE ON CLUSTER privileges
         - CH_CLUSTER \"$CH_CLUSTER\" not present in customer's system.clusters
         - HTTPS endpoint with self-signed CA (not yet supported — see README)"
}

#--------------------------- go -----------------------------------------------
if is_render_only; then
  log "mode: --render (writes YAML to $RENDER_DIR, nothing applied)"
else
  log "mode: live apply to NAMESPACE=$NAMESPACE"
fi
log "        external CH=$CH_ENDPOINT  cluster=$CH_CLUSTER  db=$CH_DATABASE  user=$CH_USER"
log "        Kafka=$KAFKA_NAME replicas=$KAFKA_REPLICAS user=$KAFKA_USER  storage=$STORAGE_CLASS"

stage0_operators
stage1_kafka
stage2_user_topics
stage3_conn_secrets
stage3_5_bootstrap_db
stage4_plf

if is_render_only; then
  log "YAML files written to $RENDER_DIR (apply in filename order):"
  for f in "$RENDER_DIR"/*.yaml; do
    [[ -f "$f" ]] && printf "    %s\n" "$(basename "$f")"
  done
  log ""
  log "NOTE: ./rendered/ is NOT a complete install bundle on its own:"
  log "  * ${MQ_CONN_SECRET_NAME} Secret is OMITTED (needs live strimzi"
  log "    cluster-ca-cert, which only exists after RdsKafka is Ready)."
  log ""
  log "Correct next step — re-run live (no --render):"
  log "    ./install.sh install.env"
  log "This re-reads ./rendered/* per stage (your edits honoured), mints"
  log "mq-conn with the live strimzi CA, waits each stage Ready, idempotent."
else
  ok "ALL STAGES PASS. Verify with ./check.sh install.env."
fi
