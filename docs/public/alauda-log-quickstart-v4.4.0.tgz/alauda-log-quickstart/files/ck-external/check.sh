#!/usr/bin/env bash
# =============================================================================
# check.sh — acceptance verifier for external-CH one-shot install
#
#   ./check.sh install.env            # runs all checks, exits 0 if ALL PASS
#
# Checks (in order):
#   1. PLF platform-default Ready=True
#   2. 3 × RdsTopic (log/event/audit) status.phase=Ready|Active
#   3. KafkaUser-ref Secret <KAFKA_USER> exists
#   4. aggregate-vector Deployment Available
#   5. razor Deployment Available
#   6. aggregate-vector / razor pods Running
#   7. schema-migrations Job(s) all Complete
#   8. external CH reachable from in-cluster razor pod (/ping returns "Ok.")
#
# NOTE: No CHI check — this mode does not install ClickHouseInstallation.
# Customer runs their own CH cluster.
# =============================================================================
set -Eeuo pipefail

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; RST=$'\e[0m'
else
  BOLD=''; RED=''; GRN=''; YLW=''; RST=''
fi
pass() { printf "%s[check] ✓%s %s\n" "$GRN" "$RST" "$*"; }
fail() { printf "%s[check] ✗%s %s\n" "$RED" "$RST" "$*"; FAILED=$((FAILED+1)); }
info() { printf "%s[check]%s %s\n"   "$BOLD" "$RST" "$*"; }

#--------------------------- env ----------------------------------------------
[[ $# -ge 1 ]] || { echo "usage: $0 install.env" >&2; exit 2; }
ENV_FILE="$1"
[[ -r "$ENV_FILE" ]] || { echo "cannot read $ENV_FILE" >&2; exit 2; }
# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

NAMESPACE="${NAMESPACE:-cpaas-system}"
KAFKA_NAME="${KAFKA_NAME:-cpaas-kafka}"
KAFKA_USER="${KAFKA_USER:-platform-logging}"
PLF_NAME="${PLF_NAME:-platform-default}"

FAILED=0

#--------------------------- 1. PLF Ready -------------------------------------
info "1. PLF/$PLF_NAME Ready"
ready="$(kubectl get plf "$PLF_NAME" -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
if [[ "$ready" == "True" ]]; then
  pass "PLF $PLF_NAME Ready=True"
else
  fail "PLF $PLF_NAME Ready=$ready (expected True)"
  kubectl get plf "$PLF_NAME" -o jsonpath='{.status.conditions[?(@.type=="Ready")].message}' 2>/dev/null | sed 's/^/        /' || true
  echo
fi

#--------------------------- 2. RdsTopic Ready --------------------------------
info "2. 3 RdsTopic status.phase=Ready|Active"
for t in alauda-log-topic alauda-event-topic alauda-audit-topic; do
  phase="$(kubectl -n "$NAMESPACE" get rdstopic "$t" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
  if [[ "$phase" == "Ready" || "$phase" == "Active" ]]; then
    pass "RdsTopic $t $phase"
  else
    fail "RdsTopic $t phase=$phase (expected Ready or Active)"
  fi
done

#--------------------------- 3. KafkaUser Secret ------------------------------
info "3. KafkaUser-ref Secret/$KAFKA_USER exists"
if kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1; then
  pass "Secret $NAMESPACE/$KAFKA_USER present"
else
  fail "Secret $NAMESPACE/$KAFKA_USER missing"
fi

#--------------------------- 4-5. Deployments Available -----------------------
info "4-5. aggregate-vector / razor Deployments Available"
for d in aggregate-vector razor; do
  avail="$(kubectl -n "$NAMESPACE" get deploy "$d" -o jsonpath='{.status.conditions[?(@.type=="Available")].status}' 2>/dev/null || true)"
  if [[ "$avail" == "True" ]]; then
    pass "Deployment $d Available"
  else
    fail "Deployment $d Available=$avail (expected True)"
  fi
done

#--------------------------- 6. Pods Running ----------------------------------
info "6. aggregate-vector / razor pods Running"
# NOTE: the operator-created aggvec and razor pods are labeled
# app.kubernetes.io/name=<name>, NOT app=<name>. The old `app in (…)` selector
# matched zero pods and was vacuously satisfied. Query both labels so one of
# them lands even if the operator label convention shifts again.
not_running="$(kubectl -n "$NAMESPACE" get pod \
  -l 'app.kubernetes.io/name in (aggregate-vector,razor)' \
  -o jsonpath='{range .items[?(@.status.phase!="Running")]}{.metadata.name}={.status.phase} {end}' 2>/dev/null || true)"
if [[ -z "$not_running" ]]; then
  running_count="$(kubectl -n "$NAMESPACE" get pod -l 'app.kubernetes.io/name in (aggregate-vector,razor)' --no-headers 2>/dev/null | wc -l)"
  if [[ "$running_count" -eq 0 ]]; then
    fail "no aggvec/razor pods found under app.kubernetes.io/name selector"
  else
    pass "$running_count aggvec/razor pods all Running"
  fi
else
  fail "non-Running pods: $not_running"
fi

#--------------------------- 7. schema-migrations Jobs Complete ---------------
# Operator-created schema-migrations Jobs carry ttlSecondsAfterFinished and may
# have been garbage-collected by the time check.sh runs. When the Job is gone
# but PLF is Ready=True, migrations provably ran (operator flips Ready only
# after schema-migrations Complete) — treat it as pass with a note.
info "7. schema-migrations Job(s) Complete (or already GC'd after Complete)"
jobs="$(kubectl -n "$NAMESPACE" get job -l 'app.kubernetes.io/name=schema-migrations' -o name 2>/dev/null || true)"
if [[ -z "$jobs" ]]; then
  if [[ "$ready" == "True" ]]; then
    pass "no schema-migrations Job present (already GC'd by ttlSecondsAfterFinished; PLF Ready=True proves it ran)"
  else
    fail "no schema-migrations Job found AND PLF not Ready — operator never derived the migration Job"
  fi
else
  while IFS= read -r j; do
    [[ -z "$j" ]] && continue
    done_cond="$(kubectl -n "$NAMESPACE" get "$j" -o jsonpath='{.status.conditions[?(@.type=="Complete")].status}' 2>/dev/null || true)"
    if [[ "$done_cond" == "True" ]]; then
      pass "$j Complete"
    else
      fail "$j Complete=$done_cond"
    fi
  done <<< "$jobs"
fi

#--------------------------- 8. ch-conn Secret references the external CH ----
# Operator-side CH reachability is already proven transitively by:
#   - PLF Ready=True (check 1)         → operator can reach CH
#   - schema-migrations Complete (7)   → migrations ran DDL on CH
# Here we just assert the ch-conn Secret endpoint field matches what install.env
# declared, so a drift between SRE intent and what reached the cluster is loud.
# (Earlier iterations tried to curl /ping from a razor pod — razor is a scratch
# image with no curl, so the probe always failed with "executable not found".)
info "8. ch-conn Secret endpoint matches install.env CH_ENDPOINT"
ch_conn_name="${CH_CONN_SECRET_NAME:-platform-default-ch-conn}"
secret_endpoint="$(kubectl -n "$NAMESPACE" get secret "$ch_conn_name" \
  -o jsonpath='{.data.endpoint}' 2>/dev/null | base64 -d 2>/dev/null || true)"
if [[ -z "$secret_endpoint" ]]; then
  fail "Secret $NAMESPACE/$ch_conn_name has no \`endpoint\` key"
elif [[ -z "${CH_ENDPOINT:-}" ]]; then
  fail "CH_ENDPOINT not set in $ENV_FILE — cannot compare"
elif [[ "$secret_endpoint" == "$CH_ENDPOINT" ]]; then
  pass "Secret endpoint == install.env CH_ENDPOINT ($secret_endpoint)"
else
  fail "drift: Secret endpoint=\"$secret_endpoint\" vs install.env CH_ENDPOINT=\"$CH_ENDPOINT\""
fi

#--------------------------- verdict ------------------------------------------
echo
if [[ "$FAILED" -eq 0 ]]; then
  printf "%s[check] ALL PASS%s\n" "$GRN" "$RST"
  exit 0
else
  printf "%s[check] %d check(s) FAILED%s\n" "$RED" "$FAILED" "$RST"
  exit 1
fi
