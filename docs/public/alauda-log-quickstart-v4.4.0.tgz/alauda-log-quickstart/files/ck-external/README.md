# ACP v4.4 日志栈 — 对接客户自有 ClickHouse(external-CH mode)

本目录是 `chart/files/ck/` 的**外部 CH 变体**:客户运行自己的 ClickHouse 集群(含 Keeper 或 ZooKeeper),我们只装 Kafka + log-storage-operator + 派生的数据面(aggregate-vector、razor、schema-migrations Job)。

## 什么时候用这个

| 条件 | ck/(自装)| ck-external/(本目录)|
|---|---|---|
| 谁拥有 ClickHouse 集群 | 我们 / Alauda chart | 客户 |
| 谁拥有 Keeper / ZooKeeper | 我们(ck/templates/10-keeper.yaml)| 客户 |
| clickhouse-operator | 装 | **不装** |
| ClickHouseInstallation(CHI) | 建 | **不建** |
| Kafka(strimzi RdsKafka) | 装(3 broker)| 装(3 broker)|
| log-storage-operator + aggvec + razor | 装 | 装 |
| 适用场景 | 全新 PoC → 转正、线上生产 | 客户已有 CH 并要求复用 / 合规要求客户自管存储 |

另见:
- 3 副本自装:`chart/files/ck/`
- 单节点 PoC 自装:`chart/files/ck-single/`
- OpenSearch 后端:`chart/files/os/`

## 客户侧的前置清单(硬要求)

对接之前请客户 DBA 确认以下 6 条,否则 PLF 永远 Ready=False:

1. **ReplicatedMergeTree 支持**。CH server 必须挂到 Keeper 或 ZooKeeper,表引擎走 Replicated*MergeTree。schema-migrations 首条 DDL 就是 `CREATE TABLE ... ON CLUSTER ... ReplicatedMergeTree(...)`。
2. **cluster 宏名可解析**。install.env 填的 `CH_CLUSTER` 必须在客户 `system.clusters` 可见:
   ```sql
   SELECT cluster, shard_num, replica_num FROM system.clusters WHERE cluster = '<CH_CLUSTER>';
   ```
3. **用户 = `admin`,权限按下**。install.sh 强制用 `admin` 账号对接客户 CH(非配置项,ACP 日志栈的所有 SRE runbook 都以 admin 为前提,非 admin 用户在后续 schema 迁移时经常碰到 CREATE TABLE / MATERIALIZED VIEW 权限不足)。请客户 DBA 在 `ON CLUSTER '<CH_CLUSTER>'` 范围对 `admin` 赋权:
   ```sql
   GRANT CREATE TABLE, DROP TABLE, ALTER TABLE ON *.* TO 'admin';
   GRANT INSERT, SELECT, TRUNCATE ON <CH_DATABASE>.* TO 'admin';
   GRANT SYSTEM DROP DNS CACHE ON *.* TO 'admin';
   ```
4. **数据库预建**。install.sh **不会** 跨进客户 CH 创建数据库(权责分明:客户 CH 是客户的)。装脚本之前,请客户 DBA 在他们自己的 `clickhouse-client` 里执行一次:
   ```sql
   CREATE DATABASE IF NOT EXISTS <CH_DATABASE> ON CLUSTER '<CH_CLUSTER>';
   ```
   漏掉这一步 → razor 启动时 ping 不到数据库,PLF Ready=False,install.sh 在 Stage 4 等 PLF 超时后退出并明确提示这条。
5. **网络可达**。cpaas-system 命名空间的 pod(aggvec、razor、schema-migrations Job)必须能解析 CH_ENDPOINT 的 DNS 并建立 TCP 连接。NetworkPolicy / 防火墙 / egress gateway 全程放行。
6. **endpoint 协议**。`CH_ENDPOINT` 必须带 `http://` 或 `https://` 前缀 + 端口。HTTP 默认 8123,HTTPS 默认 8443(以客户实际监听为准)。

`CH_SHARDS × CH_REPLICAS` 必须和客户 cluster 真实拓扑一致 —— 这两个数字会回填到 `PlatformLogForward.spec.externalStorage.{shards,replicas}`,错了则 razor / aggvec 的 `ON CLUSTER` 参数错位。

## 使用步骤

```bash
cd chart/files/ck-external/
cp install.env.example install.env
# 编辑 install.env,**必填**:
#   STORAGE_CLASS         # Kafka PVC 的 SC
#   KAFKA_STORAGE_SIZE    # 每 broker 卷大小
#   CH_ENDPOINT           # 客户 CH 的 http(s) endpoint
#   CH_PASSWORD           # admin 用户的口令
# 按需调整:CH_CLUSTER / CH_DATABASE / CH_SHARDS / CH_REPLICAS
# 不要配:CH_USER —— install.sh 强制 "admin",非 admin 用户会在 schema 迁移时踩权限坑

# 可选:先 render 看一眼
./install.sh install.env --render

# live
./install.sh install.env

# 验收
./check.sh install.env
```

## 已知限制 / 后续

1. **HTTPS 自签 / 内部 CA 暂不支持**。本次只渲染 `endpoint / cluster / database / username / password` 5 个字段,TLS 走 Go 系统信任库 —— 公认 CA 签证书的 HTTPS endpoint 自动生效,**自签或企业私有 CA 签的 HTTPS endpoint 握手会失败**。客户临时方案:(a) 暴露明文 HTTP 给我们,或 (b) 把 CA 手工塞进 aggvec / razor / schema-migrations 这几个 pod 的 trust store。正式方案会后续加 `CH_TLS_CA` / `CH_TLS_SKIP_VERIFY` 两个 install.env 开关 + `31-ch-conn-secret.yaml` 的 `tls.ca` / `tls.insecure_skip_verify` 条件块,届时更新本节。
2. **不负责 CH 侧的运维**。备份、集群扩缩、Keeper 维护、CH server 版本升级都是客户 DBA 的事。本脚本只在 schema-migrations 阶段做 DDL,其它时刻只读写数据表。
3. **升级客户 CH 版本前请打招呼**。aggvec sink / razor query / schema-migrations DDL 是按 ACP v4.4 测过的 CH 25.8 / 25.3 系列设计的,客户 CH 跨大版本升降前(尤其是 23.x ↔ 25.x)应先在非生产环境回归。
4. **卸载不删客户数据**。按 `../../docs/en/how_to/uninstall.mdx` 的卸载流程只拆我们装的组件;客户 CH 侧的库表不动,如需清理请客户 DBA 执行 `DROP DATABASE observability ON CLUSTER '<CH_CLUSTER>'`。

## 文件清单

```
chart/files/ck-external/
├── README.md                            ← 本文件
├── install.env.example                  ← 必填 CH_ENDPOINT / CH_PASSWORD;无 CK_*/KEEPER_*
├── install.sh                           ← 跳过 chop/Keeper/CHI 的 5 阶段流水线
├── check.sh                             ← 验收(无 CHI 断言 + 加 CH /ping 探活)
└── templates/
    ├── 00-subscriptions.yaml            ← 只装 strimzi + log-storage(无 chop)
    ├── 12-rdskafka.yaml                 ← 与 ck/ 一致
    ├── 20-kafka-user-topics.yaml        ← 与 ck/ 一致
    ├── 30-mq-conn-secret.yaml           ← 与 ck/ 一致(install.sh 注入 strimzi CA)
    ├── 31-ch-conn-secret.yaml           ← **从 CH_* 变量生成**,不指向集群内 CHI
    └── 40-plf.yaml                      ← externalStorage.{shards,replicas} 使用 CH_SHARDS/CH_REPLICAS
```
