#!/usr/bin/env bash
# =============================================================================
# upgrade.sh —— v4.2 / v4.3 → v4.4 升级场景的 kafka-only 装机助手
#
#   ./upgrade.sh install.env            # live apply(默认)
#   ./upgrade.sh install.env --render   # 仅渲染 YAML 到 ./rendered-upgrade/
#
# 场景(与 install.sh 的 fresh 装机互补):
#   升级场景的 ClickHouse 复用 v4.2 / v4.3 chart-alauda-log-clickhouse 装的
#   cpaas-clickhouse —— log-storage-operator auto-migration 探到老
#   AR/logclickhouse 后走 adopt,不重建 CHI、不重跑 schema DDL。SRE 侧只需
#   建 kafka 这一组资源 + platform-default-mq-conn Secret,其余由 operator
#   自动完成。
#
# 本脚本执行 ait/log-storage-operator/docs/SECRET_CONTRACT.md §6.0 升级时序
# 的 Step 0.1(装 kafka)、Step 0.2(建 mq-conn)、Step 0.3(apply
# log-storage-operator Subscription)。
#
# 建的资源(5 stage):
#   A  strimzi-kafka-operator OLM Subscription(kafka-system ns + OG + Sub)
#   B  RdsKafka CR
#   C  RdsKafkaUser + 3 RdsTopic + user password Secret
#   D  platform-default-mq-conn Secret(含 strimzi cluster-ca-cert)
#   E  log-storage-operator OLM Subscription(${NAMESPACE})—— SECRET_CONTRACT
#      §6.0 Step 0.3 收尾,operator boot 后 auto-migration 跑一次就通
#
# 不建的资源(由 operator / 老 chart 负责):
#   * chop OLM Subscription(作为 log-storage-operator 的 OLM dependency,
#     Stage E apply Sub 时 OLM 自动按 bundle/metadata/dependencies.yaml 处理;
#     集群已有 same-package 版本会 skip)
#   * ClickHouseKeeper STS、CHI(adopt v4.2 / v4.3 chart 装的 cpaas-clickhouse)
#   * platform-default-ch-conn Secret(operator auto-migration 从老
#     clickhouse-basic-auth 自动派生)
#   * PlatformLogForward CR(2026-08-05 起 operator 从老 AR 自动 Create;
#     本脚本 Stage F 替用户等到 PLF/platform-default Ready=True 再返回)
#
# IDEMPOTENT:同一 install.env 对同一集群后续重跑应为 no-op(server-side
# apply + 密码从稳定输入 sha256-derive + 每个 wait 门短路到已就绪状态)。
#
# 复用 install.env(install.sh 用同一份)。CK_* / KEEPER_* 变量 upgrade.sh
# 不读,保留它们在 install.env 中无副作用。
# =============================================================================
set -Eeuo pipefail

#--------------------------- paths & colour -----------------------------------
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TPL="$HERE/templates"

if [[ -t 1 ]]; then
  BOLD=$'\e[1m'; RED=$'\e[31m'; GRN=$'\e[32m'; YLW=$'\e[33m'; RST=$'\e[0m'
else
  BOLD=''; RED=''; GRN=''; YLW=''; RST=''
fi
log()  { printf "%s[upgrade]%s %s\n"             "$BOLD" "$RST" "$*"; }
ok()   { printf "%s[upgrade] ✓%s %s\n"           "$GRN"  "$RST" "$*"; }
warn() { printf "%s[upgrade] ! %s%s\n"           "$YLW"  "$*"   "$RST"; }
die()  { printf "%s[upgrade] ✗ %s%s\n"           "$RED"  "$*"   "$RST" >&2; exit 1; }

#--------------------------- args + env file ----------------------------------
RENDER_MODE="false"
ENV_FILE=""
for arg in "$@"; do
  case "$arg" in
    --render)   RENDER_MODE="true" ;;
    -h|--help)  sed -n '2,40p' "$0"; exit 0 ;;
    -*)         die "unknown flag: $arg (usage: $0 install.env [--render])" ;;
    *)          [[ -z "$ENV_FILE" ]] && ENV_FILE="$arg" || die "unexpected positional arg: $arg" ;;
  esac
done
[[ -n "$ENV_FILE" ]] || die "usage: $0 install.env [--render]"
[[ -r "$ENV_FILE" ]] || die "cannot read $ENV_FILE"
# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

# Separate render dir from install.sh's ./rendered/ so SRE 两套 flow 文件不混。
RENDER_DIR="$(pwd)/rendered-upgrade"
is_render_only() { [[ "$RENDER_MODE" == "true" ]]; }
if is_render_only; then
  mkdir -p "$RENDER_DIR"
fi

#--------------------------- validate -----------------------------------------
# 升级场景 CK / Keeper 走老 chart adopt,相关变量不校验。
: "${STORAGE_CLASS:?STORAGE_CLASS must be set in $ENV_FILE}"
: "${KAFKA_STORAGE_SIZE:?KAFKA_STORAGE_SIZE must be set in $ENV_FILE (e.g. 100Gi)}"

_qty_re='^[0-9]+(\.[0-9]+)?(Ki|Mi|Gi|Ti|Pi|Ei)$'
[[ "$KAFKA_STORAGE_SIZE" =~ $_qty_re ]] || die "KAFKA_STORAGE_SIZE=\"$KAFKA_STORAGE_SIZE\" must carry a unit suffix (Mi/Gi/Ti), e.g. 100Gi"
[[ "${KAFKA_CONTROLLER_STORAGE_SIZE:-5Gi}" =~ $_qty_re ]] || die "KAFKA_CONTROLLER_STORAGE_SIZE=\"$KAFKA_CONTROLLER_STORAGE_SIZE\" must carry a unit suffix"

NAMESPACE="${NAMESPACE:-cpaas-system}"
export OLM_CHANNEL_KAFKA="${OLM_CHANNEL_KAFKA:-stable}"
export OLM_CHANNEL_LOG_STORAGE="${OLM_CHANNEL_LOG_STORAGE:-alpha}"

KAFKA_NAME="${KAFKA_NAME:-cpaas-kafka}"
KAFKA_USER="${KAFKA_USER:-platform-logging}"
KAFKA_REPLICAS="${KAFKA_REPLICAS:-3}"
export KAFKA_CONTROLLER_STORAGE_SIZE="${KAFKA_CONTROLLER_STORAGE_SIZE:-5Gi}"
export KAFKA_CPU_REQUEST="${KAFKA_CPU_REQUEST:-500m}"
export KAFKA_CPU_LIMIT="${KAFKA_CPU_LIMIT:-2}"
export KAFKA_MEM_REQUEST="${KAFKA_MEM_REQUEST:-2Gi}"
export KAFKA_MEM_LIMIT="${KAFKA_MEM_LIMIT:-4Gi}"

# Password auto-generation: 与 install.sh 完全一致的 sha256-derive,保证
# 同一 install.env 跑 install.sh 和 upgrade.sh 得到同一个 kafka 密码。
if [[ -z "${KAFKA_SASL_PASSWORD:-}" ]]; then
  KAFKA_SASL_PASSWORD="$(printf '%s' "${NAMESPACE}|kafka|${KAFKA_NAME}|${KAFKA_USER}" | sha256sum | awk '{print $1}' | cut -c1-40)"
  log "KAFKA_SASL_PASSWORD empty → auto-generated 40-hex: $KAFKA_SASL_PASSWORD"
fi
export KAFKA_SASL_PASSWORD

if [[ ${#KAFKA_SASL_PASSWORD} -lt 32 ]]; then
  warn "KAFKA_SASL_PASSWORD is ${#KAFKA_SASL_PASSWORD} chars (< 32). KafkaUser may be rejected on MicroOS FIPS hosts."
fi

# Topic replication factor = min(3, KAFKA_REPLICAS).
if (( KAFKA_REPLICAS < 3 )); then
  export KAFKA_TOPIC_REPLICATION="$KAFKA_REPLICAS"
else
  export KAFKA_TOPIC_REPLICATION=3
fi

# Kafka retention / segment time (ms). Defaults: 2d retention, 1d segment.
# PoC/demo can override; segment should be <= retention/2 or expired data
# lingers in the active segment past retention.
export KAFKA_RETENTION_MS="${KAFKA_RETENTION_MS:-172800000}"
export KAFKA_SEGMENT_MS="${KAFKA_SEGMENT_MS:-86400000}"
if (( KAFKA_SEGMENT_MS > KAFKA_RETENTION_MS )); then
  warn "KAFKA_SEGMENT_MS ($KAFKA_SEGMENT_MS) > KAFKA_RETENTION_MS ($KAFKA_RETENTION_MS); actual retention may be up to segment+retention. Prefer segment <= retention/2."
fi

# TLS listener on :9093 — 必须与 mq-conn.bootstrap 对齐。
export KAFKA_PORT="9093"

# Conn Secret names — 与 install.sh 保持一致,便于 DR 两侧用不同名字(详
# install.env.example 的 "Connection Secret names" 块)。upgrade.sh 只渲
# 染 mq-conn,CH_CONN_SECRET_NAME 保留以保持 envsubst 允许列表一致性。
export MQ_CONN_SECRET_NAME="${MQ_CONN_SECRET_NAME:-platform-default-mq-conn}"
export CH_CONN_SECRET_NAME="${CH_CONN_SECRET_NAME:-platform-default-ch-conn}"

export NAMESPACE KAFKA_NAME KAFKA_USER KAFKA_REPLICAS

#--------------------------- scheduling block ---------------------------------
# 复用 install.sh 的构造规则。升级 upgrade.sh 只需要 KAFKA_SCHEDULING_BLOCK
# (RdsKafka 的 kafka/controller/entityOperator 三组 template.pod)。
TOLERATION_EFFECT="${TOLERATION_EFFECT:-NoSchedule}"
build_scheduling_block() {
  local p="$1" out=""
  if [[ -n "${TOLERATION_KEY:-}" ]]; then
    out+="${p}tolerations:"$'\n'
    out+="${p}  - key: ${TOLERATION_KEY}"$'\n'
    out+="${p}    operator: Equal"$'\n'
    out+="${p}    value: \"${TOLERATION_VALUE:-}\""$'\n'
    out+="${p}    effect: ${TOLERATION_EFFECT}"$'\n'
    out+="${p}  - key: node-role.kubernetes.io/master"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
    out+="${p}  - key: node-role.kubernetes.io/control-plane"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
    # Also tolerate ACP's `node-role.alauda.io/infra` convention taint. ACP
    # labels + taints infra-pool nodes with this key by default (bus5 实测);
    # without this the scheduler rejects any pool node that also carries it
    # because install.env only takes one user-defined toleration. Operator
    # Exists keeps the toleration value-agnostic.
    out+="${p}  - key: node-role.alauda.io/infra"$'\n'
    out+="${p}    operator: Exists"$'\n'
    out+="${p}    effect: NoSchedule"$'\n'
  else
    out+="${p}tolerations:"$'\n'
    out+="${p}  - operator: Exists"$'\n'
  fi
  if [[ -n "${NODE_AFFINITY_KEY:-}" ]]; then
    out+="${p}affinity:"$'\n'
    out+="${p}  nodeAffinity:"$'\n'
    out+="${p}    requiredDuringSchedulingIgnoredDuringExecution:"$'\n'
    out+="${p}      nodeSelectorTerms:"$'\n'
    out+="${p}        - matchExpressions:"$'\n'
    out+="${p}            - key: ${NODE_AFFINITY_KEY}"$'\n'
    out+="${p}              operator: In"$'\n'
    out+="${p}              values: [\"${NODE_AFFINITY_VALUE:-}\"]"$'\n'
  fi
  printf '%s' "$out"
}
export KAFKA_SCHEDULING_BLOCK
KAFKA_SCHEDULING_BLOCK="$(build_scheduling_block '        ')"

#--------------------------- helpers ------------------------------------------
# envsubst 列表只枚举 upgrade 场景需要的变量 —— install.env 里的 CK_* /
# KEEPER_* 不展开,模板里也没引用它们。
render() {
  local tpl="$1"
  envsubst '
    ${NAMESPACE} ${STORAGE_CLASS}
    ${OLM_CHANNEL_KAFKA} ${OLM_CHANNEL_LOG_STORAGE}
    ${KAFKA_NAME} ${KAFKA_USER} ${KAFKA_REPLICAS} ${KAFKA_PORT}
    ${KAFKA_STORAGE_SIZE} ${KAFKA_CONTROLLER_STORAGE_SIZE}
    ${KAFKA_CPU_REQUEST} ${KAFKA_CPU_LIMIT} ${KAFKA_MEM_REQUEST} ${KAFKA_MEM_LIMIT}
    ${KAFKA_SASL_PASSWORD} ${KAFKA_PASSWORD_RESOLVED} ${KAFKA_TOPIC_REPLICATION}
    ${KAFKA_RETENTION_MS} ${KAFKA_SEGMENT_MS}
    ${MQ_CONN_SECRET_NAME} ${CH_CONN_SECRET_NAME}
    ${TLS_CA_BLOCK}
    ${KAFKA_SCHEDULING_BLOCK}
  ' < "$tpl"
}

apply() {
  local tpl="$1"
  local base
  base="$(basename "$tpl")"
  local pre="$RENDER_DIR/$base"

  if is_render_only; then
    local rendered
    rendered="$(render "$tpl")"
    echo "$rendered" > "$pre"
    log "  wrote $pre"
    return 0
  fi

  if [[ -f "$pre" ]]; then
    if grep -q '__REPLACE_WITH_[A-Z0-9_]*__' "$pre"; then
      warn "  $base in ./rendered-upgrade/ contains an unresolved __REPLACE_WITH_*__ sentinel — ignoring it and re-rendering from template"
    else
      log "  apply $base (from ./rendered-upgrade/, SRE-reviewed)"
      kubectl apply --server-side --force-conflicts -f "$pre"
      return
    fi
  fi
  local rendered
  rendered="$(render "$tpl")"
  log "  apply $base (rendered inline from template)"
  echo "$rendered" | kubectl apply --server-side --force-conflicts -f -
}

wait_rollout() { kubectl -n "$1" rollout status "$2" --timeout=300s; }

wait_plf_materialize() {
  local ns="$1" name="$2"
  # 10 分钟预算,与 wait_csv_succeeded 同量级;常见 1~2 分钟出来。
  local max_iter=120 i=0
  log "  wait PLF ${ns}/${name} to be auto-created by log-storage-operator (up to 10 min)"
  while (( i < max_iter )); do
    if kubectl -n "$ns" get platformlogforward "$name" >/dev/null 2>&1; then
      ok "  PLF $name materialized"
      return 0
    fi
    if (( i > 0 && i % 12 == 11 )); then log "    still waiting ($(( (i+1) * 5 / 60 )) min elapsed, up to 10 min)"; fi
    sleep 5
    i=$((i + 1))
  done
  warn "PLF ${ns}/${name} never materialized within 10 min"
  warn "diagnose: kubectl -n $ns logs deploy/log-storage-operator-controller-manager --tail=200 | grep -iE 'auto-migration|derive-plf|refuse|suspiciousEmptyConnSecret'"
  return 1
}

wait_plf_ready() {
  local ns="$1" name="$2"
  # 20 分钟预算:PLF Ready 代表整条数据路径(aggregate-vector Deployment、
  # Nevermore CM、CH user 创建)全部就位,比单个 wait_rollout 长。
  log "  wait PLF ${ns}/${name} Ready=True (up to 20 min)"
  if kubectl -n "$ns" wait platformlogforward "$name" --for=condition=Ready --timeout=1200s 2>&1 | grep -v '^$' | sed 's/^/    /'; then
    ok "  PLF $name Ready=True"
    return 0
  fi
  warn "PLF $name not Ready after 20 min; last status:"
  kubectl -n "$ns" get platformlogforward "$name" -o jsonpath='{.status}{"\n"}' 2>/dev/null | head -c 800
  echo
  warn "diagnose: kubectl -n $ns describe platformlogforward $name | tail -40"
  return 1
}

wait_csv_succeeded() {
  local ns="$1" prefix="$2"
  log "  wait CSV ${ns}/${prefix}* Succeeded"
  for _ in {1..120}; do
    local name phase
    while IFS='=' read -r name phase; do
      [[ -z "$name" ]] && continue
      if [[ "$name" == "$prefix"* && "$phase" == "Succeeded" ]]; then
        ok "  CSV $name Succeeded"
        return 0
      fi
    done < <(kubectl -n "$ns" get csv -o jsonpath='{range .items[*]}{.metadata.name}={.status.phase}{"\n"}{end}' 2>/dev/null || true)
    sleep 5
  done
  die "CSV ${ns}/${prefix}* never reached Succeeded; kubectl -n $ns get csv for details"
}

#--------------------------- stage A: strimzi Subscription --------------------
stageA_strimzi_sub() {
  log "Stage A: strimzi-kafka-operator Subscription (kafka-system)"
  apply "$TPL/00u-strimzi-subscription.yaml"
  is_render_only && return 0
  wait_csv_succeeded kafka-system strimzi-kafka-operator
  wait_rollout kafka-system deploy/strimzi-cluster-operator || true
  ok "Stage A PASS"
}

#--------------------------- stage B: RdsKafka --------------------------------
stageB_rdskafka() {
  log "Stage B: RdsKafka ${NAMESPACE}/${KAFKA_NAME}"
  apply "$TPL/12-rdskafka.yaml"
  is_render_only && return 0

  log "  wait kafka broker pods Ready"
  # Two-phase wait: strimzi reconcile 建 kafka/controller pods 慢于 RdsKafka
  # apply。先 poll until exists,再 wait Ready;避免 kubectl wait 遇空 selector
  # 立刻返回 error: no matching resources found。
  local sel="strimzi.io/cluster=$KAFKA_NAME,strimzi.io/kind=Kafka"
  for _ in {1..60}; do
    local cnt
    cnt="$(kubectl -n "$NAMESPACE" get pod -l "$sel" --no-headers 2>/dev/null | wc -l)"
    (( cnt >= 1 )) && break
    sleep 5
  done
  (( cnt >= 1 )) || die "no kafka pods appeared under selector $sel; kubectl -n $NAMESPACE describe rdskafka/$KAFKA_NAME"
  kubectl -n "$NAMESPACE" wait --for=condition=Ready pod \
    -l "$sel" --timeout=600s \
    || die "kafka pods not Ready; kubectl -n $NAMESPACE describe rdskafka/$KAFKA_NAME"
  ok "Stage B PASS"
}

#--------------------------- stage C: KafkaUser + Topics ----------------------
stageC_user_topics() {
  log "Stage C: RdsKafkaUser + 3 RdsTopic"
  apply "$TPL/20-kafka-user-topics.yaml"
  is_render_only && return 0

  # entity-operator provisions a user Secret with the same name as the KafkaUser.
  log "  wait strimzi-maintained secret/$KAFKA_USER"
  for _ in {1..60}; do
    kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1 && break
    sleep 5
  done
  kubectl -n "$NAMESPACE" get secret "$KAFKA_USER" >/dev/null 2>&1 \
    || die "KafkaUser-ref Secret $NAMESPACE/$KAFKA_USER not materialized"

  log "  wait 3 RdsTopic status.phase=Ready|Active"
  for t in alauda-log-topic alauda-event-topic alauda-audit-topic; do
    for _ in {1..60}; do
      local phase
      phase="$(kubectl -n "$NAMESPACE" get rdstopic "$t" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
      [[ "$phase" == "Ready" || "$phase" == "Active" ]] && break
      sleep 5
    done
    [[ "$phase" == "Ready" || "$phase" == "Active" ]] || die "RdsTopic $NAMESPACE/$t phase=$phase (expect Ready|Active); kubectl -n $NAMESPACE describe rdstopic/$t"
  done
  ok "Stage C PASS"
}

#--------------------------- stage D: mq-conn Secret --------------------------
stageD_mq_conn() {
  log "Stage D: ${MQ_CONN_SECRET_NAME} Secret"

  # mq-conn.tls.ca 必须填充 —— operator effectiveMessageQueueTarget 以此判定
  # kafkaTLSEnabled=true,驱动 razor --kafka-tls-enabled + aggvec vector.toml
  # tls.enabled;空则 razor/aggvec 对 :9093 TLS listener 开 plain socket,
  # vector 日志 "unexpected EOF: broker appears to be expecting TLS"。
  #
  # Render 模式没有 live cluster 可读 strimzi cluster-ca-cert,此 Secret
  # 跳过 — SRE 流程:
  #   1) kubectl apply ./rendered-upgrade/*.yaml,等 Stage B kafka Ready
  #   2) 再 live 跑一次 ./upgrade.sh install.env (不加 --render),
  #      Stage D 从 live Secret 读 ca.crt 并物化 mq-conn。
  if is_render_only; then
    log "  render mode: skip ${MQ_CONN_SECRET_NAME} (needs live strimzi cluster-ca-cert"
    log "              which only exists after RdsKafka Ready)"
    ok "Stage D PASS (render: skipped)"
    return 0
  fi

  # Live mode: 读 strimzi ${KAFKA_NAME}-cluster-ca-cert.data["ca.crt"],
  # 以 YAML block scalar 嵌入 mq-conn。
  export KAFKA_PASSWORD_RESOLVED="${KAFKA_SASL_PASSWORD}"
  local ca_b64 ca_pem
  ca_b64="$(kubectl -n "$NAMESPACE" get secret "${KAFKA_NAME}-cluster-ca-cert" \
    -o jsonpath='{.data.ca\.crt}' 2>/dev/null || true)"
  [[ -n "$ca_b64" ]] || die "cluster CA secret ${KAFKA_NAME}-cluster-ca-cert not found; strimzi should have created it after RdsKafka Ready"
  ca_pem="$(printf '%s' "$ca_b64" | base64 -d | sed 's/^/    /')"
  export TLS_CA_BLOCK=$'  tls.ca: |\n'"$ca_pem"
  apply "$TPL/30-mq-conn-secret.yaml"
  ok "Stage D PASS"
}

#--------------------------- stage E: log-storage-operator Sub ----------------
# SECRET_CONTRACT.md §6.0 Step 0.3 收尾。放在 Stage D 之后 —— kafka 与 mq-conn
# 都就位,operator boot 第一轮 auto-migration 直接走 derive-plf 的
# platform-default-ch-conn + 自动 Create PLF/platform-default,不触发
# suspiciousEmptyConnSecret refuse 分支(Stage 顺序颠倒的 fallback 15s 内自愈,
# 不致命;见 SECRET_CONTRACT.md line 650)。
stageE_log_storage_sub() {
  log "Stage E: log-storage-operator Subscription (${NAMESPACE})"
  apply "$TPL/99u-log-storage-subscription.yaml"
  is_render_only && return 0
  wait_csv_succeeded "$NAMESPACE" log-storage-operator
  wait_rollout "$NAMESPACE" deploy/log-storage-operator-controller-manager || true
  ok "Stage E PASS"
}

#--------------------------- stage E.5: pin chop Subscription ------------------
# v4.3 的 AR/logclickhouse 包含两个 chart;其中 chart-log-clickhouse-operators
# 渲染一个 OLM Subscription 把 chop 装起来。退役老 AR 时 helm uninstall 会把这
# 个 Sub 一并删,OLM 跟着 GC chop CSV + Deployment。此时 CHI 没人 reconcile,
# 虽然 CH pods PVC-backed 不会立刻挂,但任何状态变更都停摆,属于不该的 blast
# radius。给该 Sub 打上 `helm.sh/resource-policy=keep`,out-of-band annotation
# 可以被 3-way merge 保留(见 Sentry drift 行为),后续 helm uninstall 时 keep
# 分支直接 skip 这个 Sub,chop 继续活着。
#
# 兜底写法:遍历全集群所有 OLM Subscription,只命中 spec.name=clickhouse-operator
# 的那条打 annotation。4.4 OLM dependency 若另有一条 chop Sub(在别的 ns),
# annotation 对它是 no-op(它不受 helm 管),无副作用。
#
# 上游理想位置:log-storage-operator adopt 分支已经自动给 CHI / PV / Service /
# Secret 加 keep,chop Sub 应纳入同列。本脚本是兜底,等上游跟进后可移除。
stageE5_pin_chop_sub() {
  is_render_only && return 0
  log "Stage E.5: pin chop OLM Subscription with helm.sh/resource-policy=keep"
  local pairs
  pairs=$(kubectl get subscriptions.operators.coreos.com -A \
    -o jsonpath='{range .items[?(@.spec.name=="clickhouse-operator")]}{.metadata.namespace}{"/"}{.metadata.name}{"\n"}{end}' 2>/dev/null)
  if [[ -z "$pairs" ]]; then
    warn "  no clickhouse-operator Subscription found; v4.3 chart may not have rendered yet, or already removed. Skip."
    return 0
  fi
  # Merge-patch 同时加 keep annotation 并把 installPlanApproval 翻成 Manual。
  # 平台 webhook `check-subscription.cpaas.io` 拒任何 spec.name=clickhouse-operator
  # 且 installPlanApproval=Automatic 的 Subscription update —— webhook 校验的是入站
  # 最终状态,只打 annotation 不改 spec 时 installPlanApproval 还是 Automatic,被拒。
  # 把 approval 顺带翻成 Manual 消除违规,对已 Succeeded 的 chop CSV 无影响,且平台
  # 策略本来就要求 Manual。
  while IFS='/' read -r sub_ns sub_name; do
    [[ -z "$sub_ns" || -z "$sub_name" ]] && continue
    log "  patch ${sub_ns}/${sub_name} (keep annotation + installPlanApproval=Manual)"
    kubectl -n "$sub_ns" patch subscriptions.operators.coreos.com "$sub_name" \
      --type=merge -p '{"metadata":{"annotations":{"helm.sh/resource-policy":"keep"}},"spec":{"installPlanApproval":"Manual"}}' >/dev/null
  done <<< "$pairs"
  ok "Stage E.5 PASS"
}

#--------------------------- stage F: wait auto-migration PLF -----------------
# log-storage-operator boot 后,auto-migration 从老 `AR/logclickhouse` 派生
# `platform-default-ch-conn` Secret,再创 `PLF/platform-default`。到 PLF
# `Ready=True`代表 adopt-CK 全链就位,数据可查。Stage E 结束时 operator pod
# 刚 Ready,PLF 还没写出来,直接 `kubectl get plf` 多半 NotFound,老鼠会以为
# 升级失败。本 stage 替用户把这段 wait 住。
#
# 预算:materialize 10 min + Ready 20 min = 共 30 min 上限。常见路径 1~3 分钟,
# 大头在 PLF Ready 阶段(整条数据路径就位:aggregate-vector Deployment、
# Nevermore CM、CH user 创建、所有 pods ready),慢网 / 镜像冷拉 / CH 响应慢
# 都会把它拉长。
stageF_wait_plf() {
  log "Stage F: wait auto-migration product PLF/platform-default (${NAMESPACE})"
  wait_plf_materialize "$NAMESPACE" platform-default || return 1
  wait_plf_ready       "$NAMESPACE" platform-default || return 1
  ok "Stage F PASS"
}

#--------------------------- go -----------------------------------------------
if is_render_only; then
  log "mode: --render (writes YAML to $RENDER_DIR, nothing applied)"
else
  log "mode: live apply to NAMESPACE=$NAMESPACE"
fi
log "        Kafka=$KAFKA_NAME replicas=$KAFKA_REPLICAS user=$KAFKA_USER"
log "        升级场景:CK adopt v4.2 / v4.3 chart;本脚本不建 CHI / Keeper / ch-conn / PLF"

stageA_strimzi_sub
stageB_rdskafka
stageC_user_topics
stageD_mq_conn
stageE_log_storage_sub
stageE5_pin_chop_sub
is_render_only || stageF_wait_plf

if is_render_only; then
  log "YAML files written to $RENDER_DIR (apply in filename order):"
  for f in "$RENDER_DIR"/*.yaml; do
    [[ -f "$f" ]] && printf "    %s\n" "$(basename "$f")"
  done
  log ""
  log "NOTE: ./rendered-upgrade/ is NOT a complete bundle on its own:"
  log "  * platform-default-mq-conn Secret is OMITTED (needs live strimzi"
  log "    cluster-ca-cert, which only exists after RdsKafka Ready)."
  log ""
  log "Correct next step — re-run live (no --render):"
  log "    ./upgrade.sh install.env"
else
  ok "ALL STAGES PASS. PLF/platform-default Ready=True;老 AR/logclickhouse"
  log "已被 adopt,ingest 走新 kafka → aggregate-vector → 同一个 CH,查询照常。"
fi
