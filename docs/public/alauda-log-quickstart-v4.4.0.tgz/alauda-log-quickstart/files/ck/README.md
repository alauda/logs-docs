# scripts/ck — one-shot ClickHouse install helper

ClickHouse-backend logging stack, storage cluster only. Two entry points:

| 入口 | 场景 | 建的资源 |
|---|---|---|
| `install.sh` | **Fresh 装机** | 完整 5 stage:3 OLM Subs + Keeper + CHI + RdsKafka + KafkaUser/Topics + mq-conn + ch-conn + PLF |
| `upgrade.sh` | **v4.2 / v4.3 → v4.4 升级前置** | 5 stage:strimzi Sub + RdsKafka + KafkaUser/Topics + mq-conn + log-storage-operator Sub。CHI / ch-conn / PLF 交给 operator auto-migration 从老 chart adopt |

Full SRE runbook: [`ait/log/docs/v4.4-log-arch/09-quick-start-script.md`](https://gitlab-ce.alauda.cn/ait/log/docs/-/blob/master/v4.4-log-arch/09-quick-start-script.md).

## Prerequisites

1. Dynamic StorageClass (topolvm recommended) — `kubectl get sc` shows one with a non-`no-provisioner` provisioner.
2. Three operators installed via ACP OperatorHub, each `CSV=Succeeded`:
   - **Alauda Data Services Analytical Database E1** (`clickhouse-operator`) → `cpaas-logging`
   - **Alauda Streaming Service for Kafka** (`strimzi-kafka-operator`) → `kafka-system`
   - **Alauda Container Platform Log Storage Management** (`log-storage-operator`) → `cpaas-system`

The script refuses with a clear message if any of the three CSVs is not Succeeded.

## Usage

```bash
cp install.env.example install.env
# edit install.env: set STORAGE_CLASS, KAFKA_STORAGE_SIZE, CK_STORAGE_SIZE
# passwords are optional — empty → script derives a stable sha256-based hex

# Fresh 装机(install.sh,全栈):
./install.sh install.env --render   # 渲染 YAML 到 ./rendered/,review 后再 live 跑
./install.sh install.env            # live apply end-to-end
./check.sh   install.env            # 8-point acceptance verifier

# v4.2 / v4.3 → v4.4 升级场景(upgrade.sh,仅 kafka 一组):
./upgrade.sh install.env --render   # 渲染 YAML 到 ./rendered-upgrade/
./upgrade.sh install.env            # live apply(Stage A–D)
# 跑完后,升级客户再 apply log-storage-operator Subscription;
# operator boot 时 auto-migration 从老 AR/logclickhouse 派生
# platform-default-ch-conn 并自动 Create PLF/platform-default。
```

## What the script does

Four stages, each waits for the previous stage's readiness gate:

| Stage | Produces | Ready gate |
|---|---|---|
| 1a | 3-pod Keeper StatefulSet (ck-docs recipe) | `rollout status sts/keeper` returns |
| 1b | `ClickHouseInstallation` + `RdsKafka` | CHI `.status.status=Completed`, Kafka pods Ready |
| 2 | `RdsKafkaUser` (SCRAM-SHA-512) + 3 × `RdsTopic` + user-password Secret | KafkaUser-ref Secret present, all 3 topics `Ready` |
| 3 | `platform-default-mq-conn` + `platform-default-ch-conn` | — (immediate) |
| 4 | `PlatformLogForward` (external mode) | PLF `Ready=True` |

A failed stage prints the latest describe + Event and exits non-zero. Fix the config and re-run — the script is idempotent.

**Idempotent hard-contract**: running the script a second time with the same `install.env` on the same cluster is a no-op after the first successful run. All applies are server-side (no spurious resourceVersion bumps); every readiness wait short-circuits when the condition already holds; passwords derive deterministically from `NAMESPACE`/resource-name sha256sum when left empty, so Stage 2's user-password Secret and Stage 3's conn Secrets stay bit-identical across runs.

## What `upgrade.sh` does(v4.2 / v4.3 → v4.4 升级前置)

v4.2 / v4.3 日志栈无 kafka,CK 由 chart-alauda-log-clickhouse 装的 `cpaas-clickhouse`;v4.4 pivot L 要求 kafka 必须在 operator boot 前就位,CH 走 adopt。`upgrade.sh` 执行 [`SECRET_CONTRACT.md §6.0`](https://gitlab-ce.alauda.cn/ait/log-storage-operator/-/blob/release-4.4/docs/SECRET_CONTRACT.md) 升级时序的 Step 0.1 / 0.2 / 0.3:

| Stage | Produces | Ready gate |
|---|---|---|
| A | strimzi-kafka-operator Subscription(`kafka-system` ns + OperatorGroup + Sub) | CSV `Succeeded` |
| B | `RdsKafka` | kafka broker pods Ready |
| C | `RdsKafkaUser`(SCRAM-SHA-512)+ 3 × `RdsTopic` + user-password Secret | KafkaUser-ref Secret present, 3 topics `Ready|Active` |
| D | `platform-default-mq-conn` Secret(含 strimzi cluster-ca-cert) | — (immediate) |
| E | log-storage-operator Subscription(`${NAMESPACE}`) | CSV `Succeeded` + Deployment rollout |

Stage 顺序设计:Stage E 放最后 —— kafka 与 mq-conn 都已就位,operator boot 第一轮 auto-migration 直接走 derive-plf 的 `platform-default-ch-conn` + 自动 Create PLF/platform-default,不触发 `suspiciousEmptyConnSecret` refuse 分支。

**不建**(由 operator / 老 chart 负责):
- chop OLM Subscription(作为 log-storage-operator 的 OLM dependency,Stage E apply Sub 时 OLM 按 `bundle/metadata/dependencies.yaml` 自动处理;集群已有 same-package 版本会 skip)
- ClickHouseKeeper / CHI(adopt v4.2 / v4.3 chart 装的 `cpaas-clickhouse`,不重建、不重跑 schema DDL)
- `platform-default-ch-conn` Secret(operator auto-migration 从老 `clickhouse-basic-auth` 自动派生)
- `PlatformLogForward` CR(2026-08-05 起 operator 从老 AR 自动 Create,admin 零手工)

与 `install.sh` 共用 `install.env`:`CK_*` / `KEEPER_*` 变量 `upgrade.sh` 不读,留着无副作用。kafka 密码 derive 公式两边一致,同一 `install.env` 两边跑得到同一密码。渲染目录为 `./rendered-upgrade/`,与 `install.sh` 的 `./rendered/` 分开。

## Files

```
install.sh                        # fresh install entry point (Stage 0–4)
upgrade.sh                        # v4.2 / v4.3 → v4.4 kafka-only entry point (Stage A–D)
check.sh                          # verify entry point (8 checks)
install.env.example               # config template (both scripts read it)
templates/                        # CR templates (envsubst placeholders)
  00-subscriptions.yaml                # install.sh only: 3 OLM Subs(chop + strimzi + log-storage)
  00u-strimzi-subscription.yaml        # upgrade.sh Stage A: strimzi Sub only
  99u-log-storage-subscription.yaml    # upgrade.sh Stage E: log-storage-operator Sub only
  10-keeper.yaml                       # install.sh only
  11-chi.yaml                     # install.sh only
  12-rdskafka.yaml                # shared
  20-kafka-user-topics.yaml       # shared
  30-mq-conn-secret.yaml          # shared; not emitted by --render (needs strimzi CA)
  31-ch-conn-secret.yaml          # install.sh only
  40-plf.yaml                     # install.sh only
```

## Not for

- Production clusters needing capacity planning → follow [`docs/SRE_EXTERNAL_SETUP.md`](../../docs/SRE_EXTERNAL_SETUP.md).
- OpenSearch backend → script covers ClickHouse only.
- Log-collecting (non-storage) clusters → use the standard ACP log-agent chart.
- ClickHouse tiered storage (hot/cold) → not supported here.
